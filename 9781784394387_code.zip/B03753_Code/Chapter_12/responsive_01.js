
Ext.Loader.setConfig({
    enabled: true
});

Ext.onReady(function(){
	Ext.create('Ext.container.Viewport',{		
		padding:'0px',
		layout:'border',
		items: [{
			xtype: 'panel',
			title: 'NORTH Region',
			header:false,
			region:'north',
			split: false,
			minHeight : 75,
			maxHeight : 75,				
			plugins: 'responsive',	
			html:'<div>Content of Header Zone ( W >800 ) ..!</div>', 
			responsiveConfig: {
				 // bodyStyle  : {'background-color':'#fbb040','color': '#0052b0'},
				 'width < 800': {
					hidden:true 
				 },
				 '(desktop && width >= 800)':{
					bodyStyle  : {'background-color':'#f1f1f1','color': '#277cc0'},
					hidden:false 
				 },
				 '(tablet || phone )': {
					hidden:true
				 }	
			 }
		},{
			xtype: 'panel',			
			title: 'Main Menu', //region:'west',
			header:false, 
			bodyPadding : '5px',
			collapsible: false,   // make collapsible
			region:'north',
			hidden:true,
			split: false, 
			minHeight : 75,
			maxHeight : 75,
			bodyPadding : '10px',
			bodyStyle  : {
				'background-color':'#fbb040',
				'color':'#663399',
				'font-weight':'bold',
				'font-size':'1.25em'
			},				 
			html:'<div>My Menu (w < 800) Zone..!</div>', 				
			plugins: 'responsive',	
			responsiveConfig: {
				 'width < 800': {
					 hidden:false 
				 },
				 '(desktop && width >= 800)': {
					hidden:true				
				 },
				 '(tablet || phone)': {
					hidden:false, 
					html:'<div>My Menu (phone or table) Zone..!</div>', 
				 }					 
			 }
		},{
			xtype: 'panel',			
			title: 'West Region', //region:'west',
			bodyPadding : '5px',
			width: 300,
			collapsible: true,   // make collapsible
			region:'west',
			split: true,  
			html:'<div>Content of WEST Zone..!</div>', 				
			plugins: 'responsive',	
			responsiveConfig: {
				 '(desktop && width < 800)': {
					hidden:true						
				 },
				 '(desktop && width >= 800)': {
					hidden:false 	
				 },
				 '(phone)': {
					hidden:true 	
				 },
				 '(tablet && width < 800)': {
					hidden:true
				 },
				 '(tablet && width >= 800)': {
					hidden:false
				 } 
			 }
		},{
			title: 'Center Region',
			region: 'center', 
			html:'<b>Main content</b> goes here',
			plugins: 'responsive',
			responsiveConfig:{
				'desktop':{
					title: 'Center Region - Desktop'
				},
				'!(desktop) && (tablet)':{
					title: 'Center Region - Tablet'							
				},
				'!(desktop) && (phone)':{
					title: 'Center Region - phone'														
				}
			}		
		},{
			xtype: 'panel',
			title: 'South Region is resizable',
			header: (Ext.platformTags.phone || Ext.platformTags.tablet)?false:true, 
			region: 'south',  
			bodyPadding : '5px',   
			height:200,
			split: true ,
			html:'<div>Content of South Zone..!</div>', 	
			plugins: 'responsive',
			responsiveConfig: {
				 '(desktop && width < 800)': {
					 hidden:true,
					 header:false, 
					 title:'', 
					 height:100,
					 maxHeight:175						 
				 },
				 '(desktop && width >= 800)': {	
					hidden:false,
					header:true, 
					title: 'South Region is resizable',						
					height:120 ,
					maxHeight : 175
				 },
				 '!(desktop)': { // Tablets and phones (will work)						
					hidden:false,						
					header:true, 
					minHeight : 75,
					maxHeight : 75,
					height:75, 	
					bodyStyle : {'background-color':'#66cc99','color': '#333333'}		
				 }
			 }	
		}]
	});
});