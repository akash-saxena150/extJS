
Ext.Loader.setConfig({
    enabled:true
});
Ext.define('Myapp.sample.customPanel',{
	extend : 'Ext.panel.Panel',
	alias  : 'widget.customPanel',
	title  : 'my Extended Panel',
	header : true, 
	html   : '', 
    mixins: [
          'Ext.mixin.Responsive'
    ],
	responsiveConfig: {
		 '(tablet)': {
			html   : 'my panel (desktop) content here..!',
			bodyStyle  : {'background-color':'#6d6d6d','color': '#ffffff'}
		 },
		 '(desktop)':{
			html   : 'my panel (desktop) content here..!',
			bodyStyle  : {'background-color':'#c4801c','color': '#ffffff'}
		 },
		 '(phone)': {
			html   : 'my panel (phone) content here..!',
			bodyStyle  : {'background-color':'#5e1b5e','color': '#ffffff'}
		 }	
	 }
});
Ext.onReady(function(){
	Ext.create('Ext.container.Viewport',{		
		//padding:'0px',
		layout:'fit',
		items:[{
			xtype: 'customPanel',
			title: 'my Sample Panel',
			html:'<div>Content Panel</div>'
		}]
	});
});