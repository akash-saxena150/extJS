// JavaScript Document
Ext.Loader.setConfig({
    enabled: true,
	paths:{
		Myapp:'appcode'	
	}	
});
Ext.require([
	'Ext.tip.*','Ext.data.*','Ext.tree.*'	
]);
Ext.onReady(function(){
	
	Ext.tip.QuickTipManager.init();
	var MyTreeStore = Ext.create('Ext.data.TreeStore',{
		autoLoad:true, 
		storeId:'myTreeStoreDS', 
		proxy:{
			type:'ajax',
			url:'serverside/menu.json' 			
		}		
	});	
	var MyTreePanel = Ext.create('Ext.tree.Panel',{
		title: 'My app menu', 
		width  :270, height :370, 
		frame : true, 
		store  :MyTreeStore, 
		renderTo:'myPanel'
	});
	
});