// JavaScript Document
Ext.Loader.setConfig({
    enabled: true,
	paths:{
		Myapp:'appcode'	
	}	
});
Ext.require([
	'Ext.tip.*','Ext.data.*','Ext.tree.*'	
]);
Ext.onReady(function(){
	Ext.tip.QuickTipManager.init();
	var MyTreeStore = Ext.create('Ext.data.TreeStore',{
		storeId:'myTreeStoreDS', 
		root: {
			text: 'My Application',
			expanded: true, checked:false, 
			children: [{
				text: 'app',
				checked:false,  
				children:[
					{ leaf:true, text: 'Application.js', checked:false }
				]
			},{
				text: 'controller', expanded: true, children: [], 
				checked:false
			},{
				text: 'model', expanded:true, checked:false, 
				children: [
					{ leaf:true, text: 'clients.js', checked:false },
					{ leaf:true, text: 'providers.js', checked:false },
					{ leaf:true, text: 'users.js', checked:false }
				]
			},{
				text: 'store', checked:true, 
				children: [
					{ leaf:true, text: 'clients.js', checked:false },
					{ leaf:true, text: 'providers.js', checked:true },
					{ leaf:true, text: 'users.js', checked:false}
				]
			},{
				text: 'view', checked:false, 
				children: [
					{ leaf:true, text: 'BasicTreePanel.js', checked:false },
					{ leaf:true, text: 'TreeStorePanel.js', checked:false }
				]
			},{
				text: 'resources', checked:false, 
				children: [
					{ text: 'images', checked:false },
					{ text: 'css', checked:false, 
						children: [
						{ leaf:true, text: 'main.css', checked:false },
						{ leaf:true, text: 'clients.css', checked:false }
						]
					}
				]
			}]
		}
	});		
	
	var MyTreePanel = Ext.create('Ext.tree.Panel',{
		title: 'My tree panel', 
		width  :250, height :350, 
		frame : true, 
		store  :MyTreeStore, 
		renderTo:'myPanel'
	});

	
	
});