// JavaScript Document
Ext.define('Myapp.view.nodeForm', {
    extend:'Ext.form.Panel',	
    alias: ['widget.mynodeForm'],
    requires: [
        'Ext.toolbar.Toolbar',
        'Ext.toolbar.Fill',
        'Ext.button.Button',
        'Ext.form.field.Text',
        'Ext.form.RadioGroup',
        'Ext.form.field.Radio'
    ],
    border: false, 
	frame:  true,
    height: 137, 
	width:  323, 
	bodyPadding:10, 
	header: false,
    title: '',
    dockedItems: [{
		xtype: 'toolbar', dock: 'bottom',
		items: [
			{xtype: 'tbfill'},
			{xtype: 'button',text:'Save node',action:'savenode'}
		]
    }],
    items: [{	
		xtype: 'textfield', 
		fieldLabel:'Name', 
		name:'nodetext',  
		anchor: '100%'	, 
		allowBlank:false, 
		enableKeyEvents:true,    
		listeners:{
			keyup:function(o, e){
				if(e.button==31){    
					this.setValue(this.getValue() + " ");
				}
			}
		}					
	},{	
		xtype: 'radiogroup', 
		fieldLabel: 'is leaf ? ',
		items: [
			{xtype: 'radiofield', name:'usenodetype', boxLabel: 'No',  inputValue:0},
			{xtype: 'radiofield', name:'usenodetype', boxLabel: 'yes', inputValue:1, checked: true}
		]
    }],	
	initComponent: function(){
		var me=this; 
		me.callParent();
	}
});