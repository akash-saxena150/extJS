// JavaScript Document
Ext.define('Myapp.controller.nodeForm', {
	 extend:'Ext.app.Controller',
	 refs: [
		{ref:'myform', selector:'mynodeForm', autoCreate:false, xtype:'mynodeForm'}
	 ],
	 init: function() { 
		 console.log('Initialized Users! This happens before ' +  'the Application launch() function is called');
		 this.control({
			 'button[action=savenode]': {
				 click: this.savenewNode
			 }
		 });         
	 },
	 savenewNode: function() {		
		var myTree   = Ext.ComponentQuery.query('#menuTreePanel')[0]; 
		var myTreesm = myTree.getSelectionModel(); 
		if (myTreesm.hasSelection()){ //check if has selection
			var mynode = myTreesm.getSelection()[0]; //get first selection item
		} else { 
			var mynode = myTree.getRootNode(); 
		}
		var values = this.getMyform().getValues(); 		
		var newNode = {
			text: values.nodetext, 
			leaf: (values.usenodetype==1)?true:false
		};
		mynode.insertChild(0, newNode);
		var mybtn = Ext.ComponentQuery.query('#addnodebutton')[0];
		mybtn.menu.hide();
	 }
});