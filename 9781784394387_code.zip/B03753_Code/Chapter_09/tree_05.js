// JavaScript Document
Ext.Loader.setConfig({
    enabled: true,
	paths:{
		Myapp:'appcode'	
	}	
});
Ext.require([
	'Ext.tip.*','Ext.data.*','Ext.tree.*'	
]);

Ext.define('Myapp.model.Tree', {
  extend: 'Ext.data.Model',    
  fields:[
   // {name:'text', type:'string'},
    {name:'description', type:'string'},
    {name:'level', type:'int'},
    {name:'allowaccess', type:'boolean'}
]
});

Ext.onReady(function(){
	
	Ext.tip.QuickTipManager.init();
	var MyTreeStore = Ext.create('Ext.data.TreeStore',{
		autoLoad:true, 
		model:'Myapp.model.Tree', 
		storeId:'myTreeStoreDS', 
		proxy:{
			type:'ajax',
			url:'serverside/menu_extended.json' 			
		}		
	});	
	var MyTreePanel = Ext.create('Ext.tree.Panel',{
		title: 'User profile - Select access for user...', 
		width  :670, height :430, 
		frame : true, 
		store  :MyTreeStore, 
		columns:[
			{
                xtype: 'treecolumn', //this colum will provide tree structure
                text: 'Module',
				dataIndex:'text' ,
				flex: 1,sortable: true
            },{
                //we must use the templateheader component so we can use a custom tpl
                xtype: 'templatecolumn',
                text: 'Module description',
                flex: 2,
                sortable: true,
                dataIndex:'description',
                align: 'left',
                tpl: Ext.create('Ext.XTemplate', '<div class="levelcolor_{level}">{description}</div>')
            },{
                xtype: 'checkcolumn',
                header: 'Allow access',
                dataIndex: 'allowaccess',
                width: 100,
                stopSelection: false,
                menuDisabled: true
            }
		], 
		renderTo:'myPanel'
	});
	
});