Ext.define('myApp.view.appZone',{
    extend: 'Ext.panel.Panel',
    alias: 'widget.appzone',
    requires: [
		'myApp.store.modulesTreeDs', 
        'Ext.tab.Panel',
        'Ext.tab.Tab',
        'Ext.tree.Panel',
        'Ext.tree.View'	
    ],
    layout: 'border',
    header: false,
    title: '',
    items: [{
		xtype: 'tabpanel',
		region: 'center',
		itemId: 'mainZone',
		header: false,
		title: '',
		items: [{
			xtype: 'panel',
			itemId: 'startappPanel',
			title: 'Dashboard',
			iconCls:'home-16',
			bodyPadding:5, 
			region: 'center', //html:'myApp Dashboard', 
			layout: 'anchor',
			items:[{
            	xtype:  'container',
            	margin: '0px 0px 5px 0px',
            	layout: 'anchor',
				items: [{
					xtype: 'panel',
					ui:'featuredpanel',
					frame: true,
					height: 200,
					margin: '0px 5px 0px 5px',
					title: 'Featured',
					bodyPadding: 4,					
					html: 'Place contents for FEATURED zone',
					tools: [{
						xtype: 'tool',
						type: 'prev'
					},{
						xtype: 'tool',type: 'next'
					}]
				}]
        	},{
				xtype: 'container',
				height: 200,
				layout: {
					type: 'hbox',
					align: 'stretch'
				},
				items: [{
						xtype: 'panel',
						ui:'newspanel',
						frame: true,
						flex: 2,						
						height: 150,
						html: 'Place contents for NEWS zone',
						margin: '0px 5px 0px 5px',
						bodyBorder: true,
						bodyPadding: 4,
						title: 'News',
						tools: [{
							xtype: 'tool',
							type: 'gear'
						},{
							xtype: 'tool',
							type: 'refresh'
						}]
					},{
						xtype: 'panel',
						ui:'tipspanel', 
						frame: true,						
						flex: 2,						
						height: 200,
						margin: '0px 5px 0px 5px',
						bodyBorder: true,
						bodyPadding: 4,
						title: 'Tips',
						tools: [{
							xtype: 'tool',
							type: 'search'
						},{
							xtype: 'tool',
							type: 'help'
						}],
						layout:'fit',
						items:[{
							xtype: 'panel',
							ui:'newspanel',
							title: 'Nested panel UI newspanel', 
							html: 'Place contents for TIPS zone',
							border:true, 
							bodyBorder: true
						}]
				}]
			}]
		}]
	},{
		xtype: 'panel',
		itemId: 'acessPanel',
		region: 'west',
		split: true,
		width: 180,
		iconCls:'app-modules',
		layout: 'fit',
		title: 'App modules',
		items: [{
			xtype: 'treepanel',
			header: false,
			title: 'My Tree Panel',
			store: Ext.create('myApp.store.modulesTreeDs',{storeId:'accessmodulesDs'}), //'modulesTreeDs'
			rootVisible: false
		}]
	}]
});

