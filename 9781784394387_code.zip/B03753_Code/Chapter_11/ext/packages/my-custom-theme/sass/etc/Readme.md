# my-custom-theme/sass/etc

This folder contains miscellaneous SASS files. Unlike `"my-custom-theme/sass/etc"`, these files
need to be used explicitly.
