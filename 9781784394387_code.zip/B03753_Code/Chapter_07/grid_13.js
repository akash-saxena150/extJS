// JavaScript Document
Ext.Loader.setConfig({
    enabled: true,
	paths:{
		Myapp:'appcode'	
	}	
});
Ext.require([
	'Ext.tip.*',
    'Ext.grid.*',
	'Ext.selection.*',
	'Ext.plugin.*', 
	'Ext.form.*',
	'Myapp.model.Contract',
	'Myapp.model.Customer',
	'Myapp.store.customers.Customers'
]);
Ext.onReady(function(){
	Ext.tip.QuickTipManager.init();
	var myStore = Ext.create("Myapp.store.customers.Customers");
	
	
var rowEditing = Ext.create('Ext.grid.plugin.RowEditing', {
	clicksToMoveEditor: 1,
	autoCancel: false
});	

var myGrid = Ext.create('Ext.grid.Panel',{
	height: 250, width:  980, title: 'My customers',	
	columns: [{
		xtype: 'rownumberer',
		width: 50,
		align:'center'
	},{
		xtype: 'numbercolumn',
		width: 100, dataIndex: 'id', text: 'Id',
		format: '000.00'
	},{
		width: 200,
		dataIndex: 'name',
		text: 'Customer name', 
		editor:{
			xtype:'textfield',
			allowBlank:false, 
			minLength:4, maxLength:70
		}			
	},{
		xtype: 'datecolumn',
		dataIndex: 'clientSince', width: 150,	
		text: 'Client Since',
		format: 'M-d-Y H:i', 
		editor:{
			xtype: 'datefield',
			maxValue: new Date()// limited to the current date or prior
		}
	},{
		xtype: 'checkcolumn',
		dataIndex:'sendnews', width: 120,			
		text: 'Send News ?'
	},{
		xtype: 'numbercolumn',
		dataIndex:'employees',
		width: 160,	
		format: '0',		
		text: 'Customer Employees',
		editRenderer: function(value){
			return 'can\'t edit'		
		}
	}],
	store: myStore,
	selModel:{selType:'rowmodel'},
	plugins: [rowEditing], 	
	renderTo: 'myGrid'
}); 
});