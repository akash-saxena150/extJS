// JavaScript Document
Ext.Loader.setConfig({
    enabled: true,
	paths:{
		Myapp:'appcode'	
	}	
});
Ext.require([
	'Ext.tip.*',
    'Ext.grid.*',
	'Ext.selection.*',
	'Myapp.model.Contract',
	'Myapp.model.Customer',
	'Myapp.store.customers.Customers'
]);
Ext.onReady(function(){
	Ext.tip.QuickTipManager.init();
	
	var myStore = Ext.create("Myapp.store.customers.CustomersB"); 
	
	var myGroupingSummaryFeature = Ext.create('Ext.grid.feature.GroupingSummary',{
		 groupHeaderTpl: '{columnName}: {name}',
         hideGroupedHeader: true,
         startCollapsed: false
	});
		//({rows.length} Customer{[values.rows.length > 1 ? "s" : ""]})',
	var myGrid = Ext.create('Ext.grid.Panel',{
		height: 350,
		width:  980,
		title: 'My customers',	
		columns: [{
            xtype: 'rownumberer',
			width: 50,
			align:'center'
        },{
            xtype: 'numbercolumn',
            width: 100,
            dataIndex: 'id',
            text: 'Id',
            format: '000.00',
			summaryType: 'count',
			summaryRenderer: function(value, summaryData, field, metaData){
				return Ext.String.format('{0} customer{1}', value, value !== 1 ? 's' : '');
			}
        },{
            xtype: 'templatecolumn',
            text: 'Country',
			dataIndex: 'country',			
			tpl: '<div> <div class="flag_{[values.country.toLowerCase()]}">&nbsp</div> &nbsp;&nbsp;{country}</div>'
        },{
            xtype: 'gridcolumn',
            width: 200,
            dataIndex: 'name',
            text: 'Customer name'
        },{
            xtype: 'datecolumn',
            dataIndex: 'clientSince',
			width: 150,	
            text: 'Client Since',
            //format: 'M-d-Y'
			format: 'M-d-Y H:i'
			
        },{
            xtype: 'booleancolumn',
			dataIndex:'sendnews',
			width: 120,	
            text: 'Send News?',
            falseText: 'No',
            trueText: 'Yes'
        },{
            xtype: 'checkcolumn',
			dataIndex:'sendnews',
			width: 120,			
            text: 'Send News ?'
        },{
            xtype: 'numbercolumn',
			dataIndex:'employees',
			width: 160,	
			format: '0',		
            text: 'Customer Employees',
			summaryType: 'sum'
        }
		],
		features:[myGroupingSummaryFeature], 
		store: myStore,
		selModel:{
			selType:'rowmodel', 
			mode:'SINGLE'		
		},
		renderTo: 'myGrid'
	}); 






});