// JavaScript Document
Ext.Loader.setConfig({
    enabled: true,
	paths:{
		Myapp:'appcode'	
	}	
});
Ext.require([
	'Ext.tip.*',
    'Ext.grid.*',
	'Myapp.model.Contract',
	'Myapp.model.Customer',
	'Myapp.store.customers.Customers'
]);
Ext.onReady(function(){
	Ext.tip.QuickTipManager.init();
	var myStore = Ext.create("Myapp.store.customers.Customers"); 
	var myGrid = Ext.create('Ext.grid.Panel',{
		height: 250,
		width:  800,
		title: 'My customers',	
		columns: [{
            xtype: 'rownumberer',
			width: 50,
			align:'center'
        },{
            xtype: 'numbercolumn',
            width: 70,
            dataIndex: 'id',
            text: 'Id',
            format: '000.00' //0,000.00
        },{
            xtype: 'templatecolumn',
            text: 'Country',
			dataIndex: 'country',			
			tpl: '<div> <div class="flag_{[values.country.toLowerCase()]}">&nbsp</div> &nbsp;&nbsp;{country}</div>'
        },{
            xtype: 'gridcolumn',
            width: 150,
            dataIndex: 'name',
            text: 'Customer name'
        },{
            xtype: 'datecolumn',
            dataIndex: 'clientSince',
			width: 110,	
            text: 'Client Since',
            //format: 'M-d-Y'
			format: 'M-d-Y H:i'
			
        },{
            xtype: 'booleancolumn',
			dataIndex:'sendnews',
			width: 120,	
            text: 'Send News?',
            falseText: 'No',
            trueText: 'Yes'
        },{
            xtype: 'checkcolumn',
			dataIndex:'sendnews',
			width: 120,			
            text: 'Send News ?'
        },{
            xtype: 'actioncolumn',
			width: 90,
            text: 'Actions',
            items: [{
                    iconCls: 'editicon-16',
                    tooltip: 'Edit customer',
					handler: function(grid, rowIndex, colIndex){
						var rec = grid.getStore().getAt(rowIndex);
						alert("Edit customer:" + rec.get('name'));
					}
				},{
					getClass: function(v, meta, rec) {
						if (rec.get('sendnews')==0) { 
							return 'sendmailblock-16';
						} else {
							return 'sendmail-16';
						}
					},
					getTip: function(v, meta, rec) {
						if (rec.get(' ')==0) {
							return 'Do not Send';
						} else {
							return 'Send Email for news...!';
						}
					},
					handler: function(grid, rowIndex, colIndex) {
						var rec = grid.getStore().getAt(rowIndex),
							action = (rec.get('sendnews')==0 ?'' : 'Send');
							if (action==''){ 
								Ext.Msg.alert('Alert..!', "you can't send news...!");
							} else { 
								Ext.Msg.alert(action, action + ' news to ' + rec.get('name'));
							}
					}
				}
//				,{
//                    iconCls: 'sendmail-16',
//                    tooltip: 'Send email to customer',
//					handler: function(grid, rowIndex, colIndex){						
//						var rec = grid.getStore().getAt(rowIndex);
//						alert("Send email to :" + rec.get('name'));
//					}					
//                }
            ]
        }
		],
		store: myStore, 
		renderTo: Ext.getBody()
	}); 

});