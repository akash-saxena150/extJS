// JavaScript Document
Ext.Loader.setConfig({
    enabled: true,
	paths:{
		Myapp:'appcode'	
	}	
});
Ext.require([
	'Ext.*',
//	'Ext.tip.*',
//    'Ext.grid.*',
//	'Ext.selection.*',
//	'Ext.plugin.*', 
//	'Ext.form.*',
//	'Ext.toolbar.Paging',
	'Myapp.model.Contract',
	'Myapp.model.Customer',
	'Myapp.store.customers.CustomersC'
]);
Ext.onReady(function(){
	Ext.tip.QuickTipManager.init();
var myStore = Ext.create("Myapp.store.customers.CustomersC");
	
var myGrid = Ext.create('Ext.grid.Panel',{
	height: 250, width:  980, title: 'My customers',	
	columns: [{
		xtype: 'numbercolumn',
		width: 100, dataIndex: 'id', text: 'Id',
		format: '000.00'
	},{
		width: 200,
		dataIndex: 'name',
		text: 'Customer name'		
	},{
		xtype: 'datecolumn',
		dataIndex: 'clientSince', width: 150,	
		text: 'Client Since',
		format: 'M-d-Y H:i'
	},{
		xtype: 'checkcolumn',
		dataIndex:'sendnews', width: 120,			
		text: 'Send News ?'
	},{
		xtype: 'numbercolumn',
		dataIndex:'employees',
		width: 160,	
		format: '0',		
		text: 'Customer Employees'
	}],
	store: myStore,
	selModel:{selType:'rowmodel'},
	bbar: [{ 
		xtype: 'pagingtoolbar', 
		store: myStore, 
	    displayInfo: true, 
		displayMsg : 'Displaying customers {0} - {1} of {2}'
	}],
	renderTo: 'myGrid'
}); 
});