// JavaScript Document
Ext.Loader.setConfig({
    enabled: true,
	paths:{
		Myapp:'appcode'	
	}	
});
Ext.require([
	'Ext.tip.*',
    'Ext.grid.*',
	'Ext.selection.*',
	'Myapp.model.Contract',
	'Myapp.model.Customer',
	'Myapp.store.customers.Customers'
]);
Ext.onReady(function(){
	Ext.tip.QuickTipManager.init();
	
	var myStore = Ext.create("Myapp.store.customers.Customers"); 
	
	var mySummaryFeature = {
        ftype: 'summary'
   	};
		
//	Ext.create('Ext.grid.feature.Summary',{	
//		//dock:'top'
//	});
	
	var myGrid = Ext.create('Ext.grid.Panel',{
		height: 250,
		width:  980,
		title: 'My customers',	
		columns: [{
            xtype: 'rownumberer',
			width: 50,
			align:'center'
        },{
            xtype: 'numbercolumn',
            width: 100,
            dataIndex: 'id',
            text: 'Id',
            format: '000.00',
			summaryType:'count',
			summaryRenderer: function(value, summaryData, field){
				return Ext.String.format('{0} Total customers', value );
			}
        },{
            xtype: 'templatecolumn',
            text: 'Country',
			dataIndex: 'country',			
			tpl: '<div> <div class="flag_{[values.country.toLowerCase()]}">&nbsp</div> &nbsp;&nbsp;{country}</div>'
        },{
            xtype: 'gridcolumn',
            width: 200,
            dataIndex: 'name',
            text: 'Customer name'			

        },{
            xtype: 'datecolumn',
            dataIndex: 'clientSince',
			width: 150,	
            text: 'Client Since',
			format: 'M-d-Y H:i'
        },{
            xtype: 'checkcolumn',
			dataIndex:'sendnews',
			width: 120,			
            text: 'Send News ?'
        },{
            xtype: 'numbercolumn',
			dataIndex:'employees',
			width: 160,	
			format: '0',		
            text: 'Customer Employees',
			summaryType: 'sum',
			summaryRenderer: function(value, summaryData, dataIndex){
				return Ext.String.format('{0} Total employee{1}', value, value !== 1 ? 's' : '');
			}
        }
		],
		features:[mySummaryFeature], 
		store: myStore,
		selModel:{
			selType:'rowmodel', 
			mode:'SINGLE'		
		},
		renderTo: 'myGrid'
	}); 






});