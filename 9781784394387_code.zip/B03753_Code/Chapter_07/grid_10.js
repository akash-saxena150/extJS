// JavaScript Document
Ext.Loader.setConfig({
    enabled: true,
	paths:{
		Myapp:'appcode'	
	}	
});
Ext.require([
	'Ext.tip.*',
    'Ext.grid.*',
	'Ext.selection.*',
	'Myapp.model.Contract',
	'Myapp.model.Customer',
	'Myapp.store.customers.Customers'
]);
Ext.onReady(function(){
	Ext.tip.QuickTipManager.init();
	
	var myStore = Ext.create("Myapp.store.customers.Customers"); 
	
	var myRowBodyFeature = Ext.create('Ext.grid.feature.RowBody',{
		getAdditionalData:function (data, index, record, orig){//step 2
          return {
			rowBody:'<span style="padding-left: 10px"><b>Website : </b><a href="http://' + 
				record.data.website + '" target="_blank">' +  
				record.data.website + '</a></span>'
          }; 
        }
	});
		//({rows.length} Customer{[values.rows.length > 1 ? "s" : ""]})',
	var myGrid = Ext.create('Ext.grid.Panel',{
		height: 350,
		width:  980,
		title: 'My customers',	
		columns: [{
            xtype: 'rownumberer',
			width: 50,
			align:'center'
        },{
            xtype: 'numbercolumn',
            width: 100,
            dataIndex: 'id',
            text: 'Id',
            format: '000.00',
			summaryType: 'count',
			summaryRenderer: function(value, summaryData, field, metaData){
				return Ext.String.format('{0} customer{1}', value, value !== 1 ? 's' : '');
			}
        },{
            xtype: 'templatecolumn',
            text: 'Country',
			dataIndex: 'country',			
			tpl: '<div> <div class="flag_{[values.country.toLowerCase()]}">&nbsp</div> &nbsp;&nbsp;{country}</div>'
        },{
            xtype: 'gridcolumn',
            width: 200,
            dataIndex: 'name',
            text: 'Customer name'
        },{
            xtype: 'datecolumn',
            dataIndex: 'clientSince',
			width: 150,	
            text: 'Client Since',
            //format: 'M-d-Y'
			format: 'M-d-Y H:i'
			
        },{
            xtype: 'booleancolumn',
			dataIndex:'sendnews',
			width: 120,	
            text: 'Send News?',
            falseText: 'No',
            trueText: 'Yes'
        },{
            xtype: 'checkcolumn',
			dataIndex:'sendnews',
			width: 120,			
            text: 'Send News ?'
        }
		],
		features:[myRowBodyFeature], 
		store: myStore,
		selModel:{
			selType:'rowmodel', 
			mode:'SINGLE'		
		},
		renderTo: 'myGrid'
	}); 






});