// JavaScript Document
Ext.Loader.setConfig({
    enabled: true,
	paths:{
		Myapp:'appcode'	
	}	
});
Ext.require([
	'Ext.tip.*',
    'Ext.grid.*',
	'Ext.selection.*',
	'Myapp.model.Contract',
	'Myapp.model.Customer',
	'Myapp.store.customers.Customers'
]);
Ext.onReady(function(){
	Ext.tip.QuickTipManager.init();
	var myStore = Ext.create("Myapp.store.customers.Customers"); 
	var myGrid = Ext.create('Ext.grid.Panel',{
		height: 250,
		width:  900,
		title: 'My customers',	
		columns: [{
            xtype: 'rownumberer',
			width: 50,
			align:'center'
        },{
            xtype: 'numbercolumn',
            width: 70,
            dataIndex: 'id',
            text: 'Id',
            format: '000.00' //0,000.00
        },{
            xtype: 'templatecolumn',
            text: 'Country',
			dataIndex: 'country',			
			tpl: '<div> <div class="flag_{[values.country.toLowerCase()]}">&nbsp</div> &nbsp;&nbsp;{country}</div>'
        },{
            xtype: 'gridcolumn',
            width: 150,
            dataIndex: 'name',
            text: 'Customer name'
        },{
            xtype: 'datecolumn',
            dataIndex: 'clientSince',
			width: 110,	
            text: 'Client Since',
            //format: 'M-d-Y'
			format: 'M-d-Y H:i'
			
        },{
            xtype: 'booleancolumn',
			dataIndex:'sendnews',
			width: 120,	
            text: 'Send News?',
            falseText: 'No',
            trueText: 'Yes'
        },{
            xtype: 'checkcolumn',
			dataIndex:'sendnews',
			width: 120,			
            text: 'Send News ?'
        },{
            xtype: 'actioncolumn',
			width: 90,
            text: 'Actions',
            items: [
				{
                    iconCls: 'editicon-16',
                    tooltip: 'Edit customer',
					handler: function(view, rowIndex, colIndex){
						
						var model = view.getNavigationModel(); 
						var columnName = model.column.text; 
						var columnDataIndex = model.column.dataIndex; 
						var myData = model.record.get(columnDataIndex); 
						alert('You are going to edit column: '+ columnName +  ' with the value: ' + myData);
						
						/*
						Another alternative code 
										
						var mysm= grid.getSelectionModel(); 
						var position = mysm.getPosition(); 
						var columnName 	    = grid.getHeaderCt().getGridColumns()[position.colIdx].text; 
						var columnDataIndex = grid.getHeaderCt().getGridColumns()[position.colIdx].dataIndex; 
						var myData = grid.getStore().getAt(position.rowIdx).data[columnDataIndex]; 
						// var record   = mysm.getSelection(); 
						alert('You are going to edit column: '+ columnName +  ' with the value: ' + myData);
						
						*/
					}
				}
            ]
        }
		],
		store: myStore,
		selModel:{
			selType:'cellmodel', 
			mode:'SINGLE'	
		},
		renderTo: Ext.getBody()
	}); 

});