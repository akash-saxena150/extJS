// JavaScript Document
Ext.Loader.setConfig({
    enabled: true,
	paths:{
		Myapp:'appcode'	
	}	
});
Ext.require([
	'Ext.*',
//	'Ext.tip.*',
// 	'Ext.grid.*',
//	'Ext.selection.*',
//	'Ext.plugin.*', 
//	'Ext.form.*',
	'Myapp.model.clients',
	'Myapp.store.clients'
]);
Ext.onReady(function(){
	Ext.tip.QuickTipManager.init();
	var myStore = Ext.create('Myapp.store.clients');
	var myGrid = Ext.create('Ext.grid.Panel',{
		height: 250, width:  550, title: 'My clients (buffered)',	
		columns: [{
			xtype: 'rownumberer',
			width: 50
		},{
			xtype: 'numbercolumn',
			width: 100, dataIndex: 'id', text: 'Id',
			format: '0'
		},{
			width: 200,
			dataIndex: 'name',
			text: 'name'		
		},{
			width: 200,
			dataIndex: 'lastname',
			text: 'lastname'		
		}],
		store: myStore,
		loadMask: true,
		selModel:{
			pruneRemoved: false
		},
		renderTo: 'myGrid'
	}); 
});