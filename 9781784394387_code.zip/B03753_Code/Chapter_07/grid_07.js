// JavaScript Document
Ext.Loader.setConfig({
    enabled: true,
	paths:{
		Myapp:'appcode'	
	}	
});
Ext.require([
	'Ext.tip.*',
    'Ext.grid.*',
	'Ext.selection.*',
	'Myapp.model.Contract',
	'Myapp.model.Customer',
	'Myapp.store.customers.Customers'
]);
Ext.onReady(function(){
	Ext.tip.QuickTipManager.init();	
	//Step 1
	var myEventsArea = Ext.create('Ext.form.field.TextArea',{
		itemId:'myresultArea', 
		width : 400,
		height : 200,
		renderTo:'myResults'	
	});	
	var myStore = Ext.create("Myapp.store.customers.Customers"); 
	var myGrid = Ext.create('Ext.grid.Panel',{
		height: 250,
		width:  900,
		title: 'My customers',	
		columns: [{
            xtype: 'rownumberer',
			width: 50,
			align:'center'
        },{
            xtype: 'numbercolumn',
            width: 70,
            dataIndex: 'id',
            text: 'Id',
            format: '000.00' //0,000.00
        },{
            xtype: 'templatecolumn',
            text: 'Country',
			dataIndex: 'country',			
			tpl: '<div> <div class="flag_{[values.country.toLowerCase()]}">&nbsp</div> &nbsp;&nbsp;{country}</div>'
        },{
            xtype: 'gridcolumn',
            width: 150,
            dataIndex: 'name',
            text: 'Customer name'
        },{
            xtype: 'datecolumn',
            dataIndex: 'clientSince',
			width: 110,	
            text: 'Client Since',
            //format: 'M-d-Y'
			format: 'M-d-Y H:i'
			
        },{
            xtype: 'booleancolumn',
			dataIndex:'sendnews',
			width: 120,	
            text: 'Send News?',
            falseText: 'No',
            trueText: 'Yes'
        },{
            xtype: 'checkcolumn',
			dataIndex:'sendnews',
			width: 120,			
            text: 'Send News ?'
        },{
            xtype: 'actioncolumn',
			width: 90,
            text: 'Actions',
            items: [
				{
                    iconCls: 'editicon-16',
                    tooltip: 'Edit customer',
					handler: function(view, rowIndex, colIndex){						
						var model = view.getNavigationModel(); 
						var columnName = model.column.text; 
						var columnDataIndex = model.column.dataIndex; 
						var myData = model.record.get(columnDataIndex); 
						alert('You are going to edit column: '+ columnName +  ' with the value: ' + myData);
					}
				}
            ]
        }
		],
		store: myStore,
		selModel:{
			selType:'rowmodel', 
			mode:'SINGLE'		
		},
		renderTo: 'myGrid',
		listeners:{ //Step 2
			render:{
				fn:function(grid, eOpts){
					var myResult = Ext.ComponentQuery.query('#myresultArea')[0]; 
					var currentText= '\n' + myResult.getValue();  		
					myResult.setValue('Grid has render' + currentText); 
				}
			},
			select:{
				fn:function(grid, record, index, eOpts){
					var myResult = Ext.ComponentQuery.query('#myresultArea')[0]; 
					var currentText= '\n' + myResult.getValue();  		
					myResult.setValue('Record #(' + (index + 1)  + ') selected ' + currentText); 					
				}
			},
			itemclick:{
				fn:function(grid, record, item, index, ev, Opts){
					var myResult = Ext.ComponentQuery.query('#myresultArea')[0]; 
					var currentText= '\n' + myResult.getValue();  	
					var myNewMsg = 'Item #' + (index+1) + " was clicked (curtomer id=" + record.data.id + ")";	 
					myResult.setValue(myNewMsg + currentText); 			
				}
			},
			itemkeydown:{
				fn:function(grid, record, item, index, ev, eOpts){		
					var myResult = Ext.ComponentQuery.query('#myresultArea')[0]; 
					var currentText= '\n' + myResult.getValue();  	
					var myNewMsg = '';	 
					var myKey = ev.getKey();					
					if (myKey == ev.DELETE ){  //Step 3
						myNewMsg = "Delete Record"; 
					} else if (myKey == ev.RETURN ){  //Step 3
						mynewMsg = "Edit customer #" + record.data.id + ""; 
					} else if ((myKey == ev.N && ev.shiftKey ) || mykey==ev.F8 ){
						myNewMsg  = "Add new record";
					} else if (	(myKey == ev.D && ev.shiftKey ) ){ //Step 3
						myNewMsg = "view detail of customer #"  + record.data.id + ""; 
					} else if (myKey==ev.F9 ){ //Step 3
						myNewMsg = "Other action...";
					} else { 
						return;						
					}	
					myResult.setValue(myNewMsg + currentText); 		
				}				
			}
		}
	});

});