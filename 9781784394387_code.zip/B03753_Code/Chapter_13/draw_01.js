
Ext.Loader.setConfig({
    enabled: true,
	paths: {
		//'Ext.chart': '../ext-5.1.1/packages/ext-charts/src/chart',
		'Ext.draw': '../ext-5.1.1/packages/ext-charts/src/draw'
	}	
});

Ext.require([
	'Ext.*',
    'Ext.draw.*'
]);

Ext.onReady(function(){
	
	
	
//     var drawComponent = Ext.create('Ext.draw.Component', {
//         viewBox: false,
//         items: [{
//             type: 'circle',
//             fill: '#79BB3F',
//             radius: 100,
//             x: 100,
//             y: 100
//         }]
//     });
//
//     Ext.create('Ext.Window', {
//         width: 215,
//         height: 235,
//         layout: 'fit',
//         items: [drawComponent]
//     }).show();
	
	
	var myDrawCmp = Ext.create('Ext.draw.Component', {
		viewBox: false,	
		itemId:'mypaneldraw',		
		items:[
		{
			type: 'circle', //this will draw a circle
			radius: 8, 		//the radius of our circle
			x: 250, 		//the x position of the circle
			y: 18, 			//the y position of the cirlce
			fill:'blue',
			zIndex: 2
		},{
			type: 'rect',
			x: 0,
			y: 69,
			width: 200,
			height: 6,
			fill: 'blue'
		},{ //Ok 
			type: 'ellipse',
			cx: 265,
			cy: 215,
			rx: 40,
			ry: 25,
			//fillStyle: 'url(#gradientSample)',
			//fill:'url(#gradientSample)', //  '#66cc33', //fillStyle: 'blue',
			fill:'#66cc33',					
			globalAlpha: 1,	 // style="fill:yellow;stroke:purple;stroke-width:2" />
			stroke : '#993399', 
			'stroke-width' : 2		
		},{ //Ok 
			type: "path",
			path: "M 230 110 L 300 110 L 265 190 z",
			globalAlpha: 1,
			//fillStyle: "#0066cc", 
			fill: '#16becc', 
			lineWidth : 2
		},{ //Ok 
			type: 'text',
			x: 50,
			y: 50,
			text: 'Sencha', 
			'font-size':'38px', ////fontSize: 38,
			fillStyle: 'blue'
		},{ //Ok 
			type: "image",
			src: "images/apple-touch-icon.png",
			globalAlpha: 0.9,
			x: 205,
			y: 20,
			height: 100,
			width: 100,
			listeners: {
				dblclick: function(){ 
					Ext.Msg.alert('Logo', 'event dblclick on Sencha logo');
				}
			 }
		}
		]	
	});
	
     Ext.create('Ext.Window', {
		 title:'drawing components',
		 closable:true, 
		 resizable:false,
         width: 600,
         height: 300,
         layout: 'fit',
         items: [myDrawCmp]
     }).showAt(30,50);
	
	
	
	
	
	
	/*
 	surface = myDrawCmp.surface;

	surface.add([
		{
			type: 'circle', //this will draw a circle
			radius: 8, 		//the radius of our circle
			x: 250, 		//the x position of the circle
			y: 18, 			//the y position of the cirlce
			fill:'blue',
			zIndex: 2
		},{
			type: 'rect',
			x: 0,
			y: 69,
			width: 200,
			height: 6,
			fill: 'blue'
		},{ //Ok 
			type: 'ellipse',
			cx: 265,
			cy: 215,
			rx: 40,
			ry: 25,
			//fillStyle: 'url(#gradientSample)',
			//fill:'url(#gradientSample)', //  '#66cc33', //fillStyle: 'blue',
			fill:'#66cc33',					
			globalAlpha: 1,	 // style="fill:yellow;stroke:purple;stroke-width:2" />
			stroke : '#993399', 
			'stroke-width' : 2		
		},{ //Ok 
			type: "path",
			path: "M 230 110 L 300 110 L 265 190 z",
			globalAlpha: 1,
			//fillStyle: "#0066cc", 
			fill: '#16becc', 
			lineWidth : 2
		},{ //Ok 
			type: 'text',
			x: 50,
			y: 50,
			text: 'Sencha', 
			'font-size':'38px', ////fontSize: 38,
			fillStyle: 'blue'
		},,{ //Ok 
			type: "image",
			src: "images/apple-touch-icon.png",
			globalAlpha: 0.9,
			x: 205,
			y: 20,
			height: 100,
			width: 100,
			listeners: {
				dblclick: {
					element: 'body', //bind to the underlying body property on the panel
					fn: function(){ 
						Ext.Msg.alert('Logo', 'event dblclick on Sencha logo');
					}
				}
			 }
		}] 			
	); 
	
	*/
	/*
	Ext.create('Ext.window.Window', {
			title: 'Drawing - 101',
			closable:true, 
			resizable:true, 	
			height: 350,
			width: 650,
			layout: 'fit',
			items:[myDrawCmp]
	}).show();
*/

 
});