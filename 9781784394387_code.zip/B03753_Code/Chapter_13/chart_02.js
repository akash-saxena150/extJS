Ext.Loader.setConfig({
    enabled: true,
	paths: {
		'Ext.chart': '../ext-5.1.0/packages/sencha-charts/src/chart',
		'Ext.draw' : '../ext-5.1.0/packages/sencha-charts/src/draw'
	}	
});

Ext.require([
	'Ext.*',
    'Ext.draw.*', 	
	'Ext.chart.*' 
]);

Ext.onReady(function(){
		
	var myChartStore = Ext.create('Ext.data.ArrayStore',{		
		storeId:'salesStore', 
		fields:[
			{name: 'id', type: 'int'},
			{name: 'region', type: 'string'},
			{name: 'sales', type: 'float'} ,  
			{name: 'salesb', type: 'float'} 
		], 		
		data:[
			[10001 ,"North", 15.55 , 14.66 ],
			[10002 ,"South", 23.99 , 32.45 ],		
			[10003 ,"East",  17.44 , 9.55 ],			
			[10004 ,"West",  30.00 , 32.55 ]	,				
			[10005 ,"Central", 4.45 , 1.44 ],								
			[10006 ,"OverSeas", 2.55, 27.12 ]														
		]		
	});
	
	var mychart= Ext.create('Ext.chart.PolarChart', {
		store: myChartStore, 
		insetPadding: {top: 50, left: 25, right: 25, bottom: 15},
		innerPadding: 20, 
		interactions: ['rotate', 'itemhighlight'],
		theme: 'default-gradients',
        legend: {
                docked: 'bottom'
        },
        series: {
            type: 'pie',
			angleField:'sales', // xField 
			label: {
				field:'region',
				calloutLine: {
					length: 60,
					width: 3
				}
			},
			highlight: true,
			tooltip: {
				trackMouse: true,
				renderer: function(storeItem, item) {
					this.setHtml(storeItem.get('region') + ': ' + storeItem.get('salesa') );
				}
			}			
        },
		sprites: {
			type: 'text',
			text: 'My Company - 2015',
			fontSize: 22,
			fillStyle: '#993366',
			width: 100,
			height: 30,
			x: 40, // the sprite x position
			y: 25 // the sprite y position
		}		
	});

	Ext.create('Ext.window.Window', {
			title: 'Charts 101',
			closable:true, 
			resizable:true, 	
			height: 400,
			width: 650,
			layout: 'fit',
			html:'My Chart', 
			items:[mychart]
			
	}).show();


});