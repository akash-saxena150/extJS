// JavaScript Document
Ext.define('myApp.controller.app', {
		extend: 'Ext.app.Controller',	
		requires:[
			'myApp.store.modulesTreeDs',
			'myApp.view.appZone',
			'myApp.view.myViewport',
			'myApp.view.myChartSample'	
		],
		config:{
			refs:{
				myappzone:{
					selector:'appzone', 
					xtype:'appzone', 
					autoCreate:false
				}
			},
			routes:{
				':id': {
					action: 'handleRoute',
					before: 'beforeHandleRoute'
				}
			} 
		},
		init: function() {
			console.log('app controller init');
			var me=this; 
			this.control({
				'appzone #acessPanel treepanel'	:{
					itemdblclick: me.handleAccess	
				}								
			});
		},
		handleAccess:function (cmpView, record, itemx, index, evt, eOpts ){
			//console.log('Action for handle access : ' + record.data.text );
			var me=this, moduleData = record.data; 		
			if (moduleData.hasOwnProperty('moduleType')){
				var typeModule = moduleData.moduleType; 
				if (typeModule==''){ 				
					return; 
				} else if (typeModule=='link'){ 	
					me.executeLink(moduleData);
				} else if (typeModule=='window'){ 	
					me.runWindow(moduleData);
				} else if (typeModule=='module'){ 	
					if (moduleData.options=="myApp.view.modules.customers"){ 
						this.redirectTo('customers', true);
						return; 
					} else {  
						me.addModule(moduleData);			
					} 
				}			
			}
		},
		addModule:function(data){
			//console.log('Adding Module: ' + Data.options );	
			var me=this;
			var myZone = me.getMyappzone(); 
			var ModulesTab = myZone.query('tabpanel#mainZone')[0]; 
			var existModule= false;
			for (var i=0;i<ModulesTab.items.items.length;i++){ 
				if ( ModulesTab.items.items[i].xtype==data.moduleAlias ){
					existModule	=true; 
					break; 
				}
			} 
			if (existModule){
				ModulesTab.setActiveTab(i); 
				return; 			
			} else { 
				var mynewModule = Ext.create(data.options,{iconCls:data.iconCls, title:data.text , altText:data.text});	
				ModulesTab.add(mynewModule);			
				ModulesTab.setActiveTab(( ModulesTab.items.items.length -1 ));
				return; 		
			}
		},
		runWindow:function(data){
			console.log('Execute window: ' + Data.options );
			Ext.Msg.alert("Window module","here we show window:<b>" + data.text+ "</b>");
		},
		executeLink:function(data){
			console.log('launch Link: ' + Data.options );
			window.open(data.options); 
		}, 
		beforeHandleRoute: function(id, action) {
			if (id!='customers'){ 
				Ext.Msg.alert("Route error","invalid action...!");	
				action.stop();
			} else { 
				action.resume(); 
			} 			
		}, 
		handleRoute: function(id) {
			if (id=='customers'){ 
				var myStore  = this.getMyappzone().query('treepanel')[0].getStore();
				var myRecord = myStore.findNode('text','Customers'); 
				if (myRecord!=undefined){
					this.addModule(myRecord.data); 
				} else{ 
					//console.log("Records in store=" + myStore.getCount() ); 
					//console.log("Record not defined of customers or not loaded")
					var dataCustomers = {
						leaf: true,
						text: "Customers",
						allowaccess:false,
						description:"Customer administration",
						level:3,
						iconCls:"customer-16",
						moduleType:"module",
						moduleAlias:"customersmodule",
						options:"myApp.view.modules.customers"
					}; 
					this.addModule(dataCustomers); 
					//Ext.Msg.alert("Route error","eror getting customers data access...!");	
				} 
			} 
		}	 
});


/*
Ext.define('myApp.controller.app', {
	extend: 'Ext.app.Controller',	
	requires:[
		'myApp.store.modulesTreeDs',
		'myApp.view.appZone',
		'myApp.view.myViewport'	,
		'myApp.view.myChartSample'
	],
	config:{
		refs:{
			myappzone:{
				selector:'appzone', xtype:'appzone', autoCreate:false
			}
		},
		routes:{
            ':id': {
                action: 'handleRoute',
                before: 'beforeHandleRoute'
            }
        } 
	},
	init: function() {
        //console.log('app controller init');
		var me=this; 
		this.control({
			'appzone #acessPanel treepanel'	:{
				itemdblclick: me.handleAccess	
			}											
		});				
    },
	handleAccess:function (cmpView, record, itemx, index, evt, eOpts ){
		//console.log('Action for handle access : ' + record.data.text );
		var me=this, moduleData = record.data; 		
		if (moduleData.hasOwnProperty('moduleType')){
			var typeModule = moduleData.moduleType; 
			if (typeModule==''){ 				
				return; 
			} else if (typeModule=='link'){ 	
				me.executeLink(moduleData);
			} else if (typeModule=='window'){ 	
				me.runWindow(moduleData);
			} else if (typeModule=='module'){ 	
				if (moduleData.options=="myApp.view.modules.customers"){ 
					this.redirectTo('customers', true);
					return; 
				} else {  
					me.addModule(moduleData);			
				} 
			}			
		}
	},
	addModule:function(data){
		//console.log('Adding Module: ' + Data.options );	
		var me=this;
		var myZone = me.getMyappzone(); 
		var ModulesTab = myZone.query('tabpanel#mainZone')[0]; 
		var existModule= false;
		for (var i=0;i<ModulesTab.items.items.length;i++){ 
			if ( ModulesTab.items.items[i].xtype==data.moduleAlias ){
				existModule	=true; 
				break; 
			}
		} 
		if (existModule){
			ModulesTab.setActiveTab(i); 
			return; 			
		} else { 
			var mynewModule = Ext.create(data.options,{iconCls:data.iconCls, title:data.text , altText:data.text});	
			ModulesTab.add(mynewModule);			
			ModulesTab.setActiveTab(( ModulesTab.items.items.length -1 ));
			return; 		
		}
	},
	runWindow:function(data){
		//console.log('Execute window: ' + Data.options );
		Ext.Msg.alert("Window module","here we show window:<b>" + data.text+ "</b>");
		//var mynewWindow = Ext.create(Data.options,{modal:true, iconCls:Data.iconCls, title:'New : ' + Data.text });
		//mynewWindow.show();
	},
	executeLink:function(data){
		//console.log('launch Link: ' + Data.options );
		window.open(data.options); 
	}, 
	beforeHandleRoute: function(id, action) {
		if (id!='customers'){ 
			Ext.Msg.alert("Route error","invalid action...!");	
			action.stop();
		} else { 
			action.resume(); 
		} 			
	}, 
	handleRoute: function(id) {
		if (id=='customers'){ 
			var myStore  = this.getMyappzone().query('treepanel')[0].getStore();
			var myRecord = myStore.findNode('text','Customers'); 
			if (myRecord!=undefined){
				this.addModule(myRecord.data); 
			} else{ 
				//console.log("Records in store=" + myStore.getCount() ); 
				//console.log("Record not defined of customers or not loaded")
				var dataCustomers = {
					leaf: true,
					text: "Customers",
					allowaccess:false,
					description:"Customer administration",
					level:3,
					iconCls:"customer-16",
					moduleType:"module",
					moduleAlias:"customersmodule",
					options:"myApp.view.modules.customers"
				}; 
				this.addModule(dataCustomers); 
				//Ext.Msg.alert("Route error","eror getting customers data access...!");	
			} 
		} 
	}	
});
*/