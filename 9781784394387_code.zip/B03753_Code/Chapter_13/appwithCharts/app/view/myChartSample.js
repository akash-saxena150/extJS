Ext.define('myApp.view.myChartSample',{
    extend: 'Ext.panel.Panel',
    alias: 'widget.myChartSamplePanel',
	xtype: 'mychartPanel', 
    requires: [	
	  'Ext.draw.*',
	  'Ext.chart.*'
    ],
	bodyPadding:5, 
	iconCls:'chartx-16',
	closable:true, 
	title:'My Chart',
	layout:'fit', 
	initComponent: function() { //step 4 
		var me=this;
		var myChartStore = Ext.create('Ext.data.ArrayStore',{		
			storeId:'salesStore', 
			fields:[
				{name: 'id', type: 'int'},
				{name: 'region', type: 'string'},
				{name: 'sales', type: 'float'} ,  
				{name: 'salesb', type: 'float'} 
			], 		
			data:[
				[10001 ,"North", 1500.55 , 1450.66 ],
				[10002 ,"South", 2344.99 , 3200.45 ],		
				[10003 ,"East",  1750.44 , 950.55 ],			
				[10004 ,"West",  3000.00 , 3200.55 ]	,				
				[10005 ,"Central", 4523.45 , 1963.44 ],								
				[10006 ,"OverSeas", 2489.55, 2786.12 ]														
			]		
		});
		var mychart= Ext.create('Ext.chart.CartesianChart', {
			store: myChartStore, 
			insetPadding: {top: 50, left: 25, right: 25, bottom: 15}, 
			interactions: 'itemhighlight',
			axes: [{
				type: 'numeric',
				position: 'left',
				title: {
					text: 'Sales 1st to 3th Quarter',
					fontSize: 14,
					fillStyle:'#0d7179'
				},
				fields: 'sales' 
			}, {
				type: 'category',
				position: 'bottom',
				title: {
					text: 'Sales by Branch',
					fontSize: 18,
					fillStyle:'#277cc0'
				},
				fields:'region'
			}],
			series: {
				type: 'bar',
				title:['Main branch','Branch B'], 
				xField: 'region',
				yField: 'sales',
				style:{
					strokeStyle: '#999999',
					fillStyle: '#cccc99'		
				},
				highlight:{
					strokeStyle: '#990000',
					fillStyle: '#ffcc66',
					lineDash: [5, 3]
				},			
				label: {
					field: 'sales',
					display: 'insideEnd'
				}			
			},
			sprites: {
				type: 'text',
				text: 'My Company - 2015',
				fontSize: 22,
				fillStyle: '#993366',
				width: 100,
				height: 30,
				x: 40, // the sprite x position
				y: 25 // the sprite y position
			}		
		});
		me.items = [mychart];
        me.tbar = ['->',
            {
                text: 'Download',
                handler: function() {
                    var chart = me.down('cartesian');
					chart.download({
						filename: 'MyCompany_chart2015'
					});
                }
            }
        ];
		me.callParent();
	}
});