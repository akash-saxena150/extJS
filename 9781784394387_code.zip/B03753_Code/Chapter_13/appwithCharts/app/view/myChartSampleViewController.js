// JavaScript Document
Ext.define('myApp.view.myChartSampleViewController', {
    extend: 'Ext.app.ViewModel',
    alias: 'controller.myChartSample'
});
