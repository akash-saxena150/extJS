Ext.define('myApp.view.inDevelopment',{
    extend: 'Ext.panel.Panel',
    alias: 'widget.indevelomentpanel',
	xtype: 'indevelomentpanel', 		
	bodyPadding:5, 
	iconCls:'warning-module',
	closable:true, 
	title:'In Development',
	initComponent: function() { //step 4 
		var me=this;		
	    me.html='<h2>'+ me.altText +'</h2><h3>module in development...!</h3>';
		me.callParent();
	}
});