Read chapter 10 of the book, 
after the part on using Sencha CMD to create the basic application skeleton 
in your application folder paste / overwrite these folders in order you have the full application functional

this folder contains worked files only
