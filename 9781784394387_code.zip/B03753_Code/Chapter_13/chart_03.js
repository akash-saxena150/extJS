Ext.Loader.setConfig({
    enabled: true,
	paths: {
		'Ext.chart': '../ext-5.1.0/packages/sencha-charts/src/chart',
		'Ext.draw' : '../ext-5.1.0/packages/sencha-charts/src/draw'
	}	
});

Ext.require([
	'Ext.*',
    'Ext.draw.*', 	
	'Ext.chart.*' 
]);

Ext.onReady(function(){
		
	var myChartStore = Ext.create('Ext.data.ArrayStore',{		
		storeId:'salesStore', 
		fields:[
			{name: 'id', type: 'int'},
			{name: 'region', type: 'string'},
			{name: 'salesa', type: 'float'} ,  
			{name: 'salesb', type: 'float'} 
		], 		
		data:[
			[10001 ,"North", 1500.55 , 1450.66 ],
			[10002 ,"South", 2344.99 , 3200.45 ],		
			[10003 ,"East",  1750.44 , 950.55 ],			
			[10004 ,"West",  3000.00 , 3200.55 ]	,				
			[10005 ,"Central", 4523.45 , 1963.44 ],								
			[10006 ,"OverSeas", 2489.55, 2786.12 ]														
		]		
	});
	
	var mychart= Ext.create('Ext.chart.CartesianChart', {
		store: myChartStore, 
		insetPadding: {top: 50, left: 25, right: 25, bottom: 15}, 
		interactions: 'itemhighlight',
        theme: {
            type: 'muted'
        },		
 		axes: [{
            type: 'numeric3d',
            position: 'left',
            title: {
                text: 'Sales 1st to 3th Quarter',
                fontSize: 14,
				fillStyle:'#0d7179'
            },
			fields: 'salesa' ,
			majorTickSteps: 10,
            grid: {
                odd: {
                    fillStyle: 'rgba(245, 245, 245, 1.0)'
                },
                even: {
                    fillStyle: 'rgba(255, 255, 255, 1.0)'
                }
            }			
        }, {
			type: 'category',
            position: 'bottom',
            title: {
                text: 'Sales by Branch',
                fontSize: 18,
				fillStyle:'#277cc0'
            },
            fields:'region'
        }],
        series: {
            type: 'bar3d',
			title:['Main branch','Branch B'], 
            xField: 'region',
            yField: 'salesa',
			style:{
				minGapWidth: 10		
			},
			highlight:true,			
			label: {
				field: 'salesa',
				display: 'insideEnd'
			}			
        },
		sprites: {
			type: 'text',
			text: 'My Company - 2015',
			fontSize: 22,
			fillStyle: '#993366',
			width: 100,
			height: 30,
			x: 40, // the sprite x position
			y: 25 // the sprite y position
		}		
	});

	Ext.create('Ext.window.Window', {
			title: 'Charts 101',
			closable:true, 
			resizable:true, 	
			height: 400,
			width: 650,
			layout: 'fit',
			html:'My CHart', 
			items:[mychart]
			
	}).show();


});