Ext.Loader.setConfig({
    enabled: true,
	paths: {	
		'Ext.draw': '../ext-5.1.1/packages/ext-charts/src/draw'
	}	
});
Ext.require([
	'Ext.*',
    'Ext.draw.*'
]);
Ext.onReady(function(){
	var myDrawCmp = Ext.create('Ext.draw.Component', {
		viewBox: false,	
		itemId:'mypaneldraw',
		style:'background-color:#999999', 
		items:[
		{ //Ok 
			type: 'text',
			x: 10,
			y: 10,
			text: 'My Pac-Man', 
			'font-size':'18px', ////fontSize: 38,
			fillStyle: 'blue'
		},{
			type: 'rect',
			x: 0,
			y: 45,
			width: 600,
			height: 60,
			fill: '#ffffff',
			zIndex:1
		},{
			type: "image",
			src: "images/inkyghost.gif",
			x: 100,
			y: 50,
			height: 50,
			width:  50,
			zIndex:2
		}	
		]	
	});
	
    var myWindow = Ext.create('Ext.Window', {
		 title:'drawing components',
		 closable:true, 
		 resizable:false,
         width: 600,
         height: 300,
         layout: 'fit',
         items: [myDrawCmp]
    });
		
	myWindow.on({
		afterRender:{
			fn:function(cmpx, eOpts){
					
				var myPacman = Ext.create('Ext.draw.Sprite',{ // we create the ball sprite
					type: "image",
					src: "images/pacman02.gif",
					x: 10,
					y: 50,
					height: 50,
					width:  50,
					zIndex:3
				});
				/*
				 { //Ok 
						type: "image",
						src: "images/pacman02.gif",
						x: 10,
						y: 50,
						height: 50,
						width:  50,
						zIndex:3
				};
				*/			
				myDrawCmp.surface.add([
					myPacman,
					{
						type: "image",
						src: "images/inkyghost.gif",
						x: 160,
						y: 50,
						height: 50,
						width:  50,
						zIndex:2
					}	
				]);
				myDrawCmp.surface.renderAll();	 //myDrawCmp.getSurface().add(myGhost);
				var runner = new Ext.util.TaskRunner(); 
				var task = runner.newTask({ //start a task
					 run: function () {
						var xp=0; 
						var itemPacman = myDrawCmp.surface.items.items[4]; 
						var itemGhost   = myDrawCmp.surface.items.items[2]; 
						var itemGhostB  = myDrawCmp.surface.items.items[3];
						var xp =itemPacman.attr.x; xp+=4; 
						if (xp>=600){ xp= (-200); }
						var xg =itemGhost.attr.x; xg+=4; 
						if (xg>=600){ xg= (-150); }
						var xgg =itemGhostB.attr.x; xgg+=4;
						if (xgg>=600){ xgg= (-100); }
						itemPacman.setAttributes({x:xp}, true );
						itemGhost.setAttributes({x:xg}, true );
						itemGhostB.setAttributes({x:xgg}, true );
						// myDrawCmp.surface.renderAll();	 	
					 },
					 interval: 30, 
					 scope:this 
				});
				task.start(); // start the task
			}, 
			delay:400, 		
			scope:this	
		}	
	}); 
	myWindow.showAt(30,50);
});