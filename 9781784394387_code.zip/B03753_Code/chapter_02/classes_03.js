//Chapter 02 - code 03
var pre  = Ext.Class.getDefaultPreprocessors(),
post	 = Ext.ClassManager.defaultPostprocessors;
console.log(pre);
console.log(post);
