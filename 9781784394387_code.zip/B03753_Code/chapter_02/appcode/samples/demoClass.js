// JavaScript Document
Ext.define("MyApp.samples.demoClass",{
	initialValue:0,
	constructor: function (config){
		Ext.apply(this, config || {});
	},
	getDescription: function(){
		return 'This is a demoClass with initial Value of:' + this.initialValue;
	}	
  
});
