
Ext.Loader.setConfig({
    enabled: true
});

Ext.require([
    'Ext.button.*'
]);

Ext.onReady(function(){
		
	var myButton = Ext.create('Ext.button.Button',{
		text:'My first small button',
		scale:'small', 			
		renderTo:Ext.getBody()
	});
	
	var myButtonB = Ext.create('Ext.button.Button',{
		text:'My first medium button',
		scale:'medium', 			
		renderTo:Ext.getBody()
	});	
	
	var myButtonC = Ext.create('Ext.button.Button',{
		text:'My first large button',
		scale:'large', 			
		renderTo:Ext.getBody()
	});			
	
});
