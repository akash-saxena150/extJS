
Ext.Loader.setConfig({
    enabled: true
});

Ext.require([
    'Ext.button.*',
	'Ext.window.*'
]);

Ext.onReady(function(){
		
	var myButtona = Ext.create('Ext.button.Button',{
		text:'1st button',
		iconCls:'addicon-16',
		iconAlign:'left',
		renderTo:'normalbuttons'
	});
	
	myButtona.on('click',function(){
		Ext.Msg.alert("Click event","You clicked left icon button..!");
	});
	
	var myButtonb = Ext.create('Ext.button.Button',{
		text:'2nd button',
		iconCls:'addicon-16',
		renderTo:'normalbuttons'
	});
	
	var myButtonc = Ext.create('Ext.button.Button',{
		text:'3th button',
		iconCls:'addicon-16',
		renderTo:'normalbuttons'
	});	
		
	var myButtond = Ext.create('Ext.button.Button',{
		text:'4th button',
		iconCls:'addicon-16',
		renderTo:'normalbuttons'
	});	
	
	var mySegmentedbuttons = Ext.create('Ext.button.Segmented',{
		renderTo:'segmentedbuttons',
		vertical:false, 
		items:[{
				xtype: 'button', text:'1st button', iconCls:'addicon-16'							
			},{
				text:'2nd button', iconCls:'addicon-16'						
			},{
				text:'3th button', iconCls:'addicon-16'						
			},{
				text:'4th button', iconCls:'addicon-16'						
			}
		]			
	});
	
});
