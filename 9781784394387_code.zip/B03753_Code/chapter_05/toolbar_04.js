// JavaScript Document
Ext.Loader.setConfig({
    enabled: true
});

Ext.require([
    'Ext.button.*',
	'Ext.toolbar.*',
	'Ext.menu.*',
	'Ext.window.*'	
]);

Ext.onReady(function(){
			
var myPanel = Ext.create('Ext.panel.Panel',{
	title:'My first toolbar...', 
	width:600,
	height:200, 
	dockedItems:[{ //Step 1
		xtype : 'toolbar',				
		dock: 'top', //Step 2
		items:[
			{ xtype:'buttongroup', 
			  title:'Actions',
			  columns:2, 
			  items:[
				{ text:'New', iconCls:'addicon-32', scale:'large', rowspan:2, iconAlign:'top' },	
				{ text:'Edit', iconCls:'editicon-16'  },				
				{ text:'Remove', iconCls:'deleteicon-16' }
			  ]
			},{ 
			  xtype:'buttongroup', title:'Print / Export & Help',
			  defaults:{ scale:'large', iconAlign:'top' },
			  items:[			  
				{ text:'Export', iconCls:'export-32' },
				{ text:'Print', iconCls:'print-32' }				
			  ]			  
			},{ 
			  xtype:'buttongroup', title:'Help',
			  items:[			  
				{ text:'Help', iconCls:'help-32', scale:'large', iconAlign:'bottom' }			
			  ]			  
			}
		]
	}],
	renderTo:Ext.getBody()		
});		
	
	
});
