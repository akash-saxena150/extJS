// code based on chapter 02 - Singleton Class (singleton_01.js)
Ext.define('Myapp.CompanyConstants',{
	singleton: true, 	
	companyName: 'Extjs code developers Corp.',
	workingDays: 'Monday to Friday', 
	website:'www.extjscodedevelopers.com', 		
	welcomeEmployee:function (employee){
		return "Hello " + employee.getName() + " you are now working for " + this.companyName; 		
	}
});
// Base class Employee  using config
Ext.define('Myapp.sample.Employee',{
    mixins: {
	   observable: 'Ext.util.Observable'
    },
	statics:{
		instanceCount:0, 		
		payrollId:1000,	
		nextId : function(){			
			return (this.payrollId + this.instanceCount);	
		}
	},
	config:{
		name:'Unkown',
		lastName:'Unkown',
		age:0,	
		isOld:false, 
		payrollNumber:0		
	},
	constructor: function (config){		
		this.initConfig(config); 
		this.mixins.observable.constructor.call(this, config);
		this.setPayrollNumber(  this.statics().nextId() ); 
		this.self.instanceCount ++;			
	},
	work: function( task ){
		console.log( this.getName() + ' is working on: ' + task);
	},
    applyAge: function(newAge) {
		this.setIsOld ( (newAge>=90) ); 
		return newAge;
    }, 
	getTotalEmployees: function(){
		return this.statics().instanceCount;
	},
	quitJob:function(){		
		this.fireEvent('quit', this.getName(), new Date(), 2, 1 , 'more params...' ); 
	}
});

var patricia = Ext.create('Myapp.sample.Employee', {
	name:'Patricia', lastName:'Diaz', age:21, isOld:false,  
	listeners:{
		'quit':function(EmployeeName, quitDate, param , paramb, paramc ){ 
			console.log('Event quit launched'); 
			console.log('Employee:' + EmployeeName); 
			console.log('Date:' + Ext.util.Format.date(quitDate, 'Y-m-d H:i') ); 
			console.log('Param :' + param);
			console.log('Param B:' + paramb);
			console.log('Param C:' + paramc);								
		} 
	}
}); 
console.log( Myapp.CompanyConstants.welcomeEmployee(patricia)  ); 

// 2nd way to define the listener
//patricia.on({
//	'quit':function(EmployeeName, quitDate, param , paramb, paramc ){ 
//	
//		console.log('Event quit launched'); 
//		console.log('Employee:' + EmployeeName); 
//		console.log('Date:' + Ext.util.Format.date(quitDate, 'Y-m-d H:i') ); 
//		console.log('Param :' + param);
//		console.log('Param B:' + paramb);
//		console.log('Param C:' + paramc);				
//		
//	} 
//});

patricia.quitJob();
