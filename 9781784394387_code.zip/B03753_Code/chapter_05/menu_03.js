
Ext.Loader.setConfig({
    enabled: true
});

Ext.require([
    'Ext.button.*',
	'Ext.window.*'
]);

Ext.onReady(function(){
		
	var myButton = Ext.create('Ext.button.Button',{
		text:'Add payment method...',
		iconCls:'addicon-32',
		iconAlign:'left',
		scale:'large',
		renderTo:'normalbuttons',
		menu:[{
				text:'Master Card',
				listeners:{  // Option 1
					click:function(){
						Ext.Msg.alert("Click event","You selected Master Card..!");	
					}
				}			
			},{
				text:'Visa', //Option 2
				handler:onMenuItemClick
			},{
				text:'PayPal', 
				listeners:{ //Option 3
					'click':{fn:onMenuItemClick}
				}
			},{
				text:'Other...', 
				handler:onMenuItemClick
			}					
		]
	});
	function onMenuItemClick(itemBtn, Event){
		var optionString = itemBtn.text;
		Ext.Msg.alert("Click event","You selected " + optionString +  " ..!");	
	}
	
});
