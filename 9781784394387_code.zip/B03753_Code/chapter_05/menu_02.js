
Ext.Loader.setConfig({
    enabled: true
});

Ext.require([
    'Ext.button.*',
	'Ext.window.*'
]);

Ext.onReady(function(){
				
	//Step 1
	var menuItemA = Ext.create('Ext.menu.Item',{text:'Master card'});
	//Step 2
	var menu = Ext.create('Ext.menu.Menu',{
	items : [	//Step 3
		menuItemA,	 // Variable
		Ext.create('Ext.menu.Item',{text:'American Express'}),  // constructor
		{text:'Other...'} //object config 
	]
	});
	
		
	var myButton = Ext.create('Ext.button.Button',{
		text:'Add payment method...',
		iconCls:'addicon-32',
		iconAlign:'left',
		scale:'large',
		renderTo:'normalbuttons',
		menu:menu
	});
	
});
