// JavaScript Document
Ext.Loader.setConfig({
    enabled: true
});

Ext.require([
	'Ext.window.*', //'Ext.MessageBox',
	'Ext.data.*', 
    'Ext.button.*',
	'Ext.toolbar.*',
	'Ext.menu.*'
]);

Ext.define('Myapp.sample.store.mainMenu', {
    extend: 'Ext.data.TreeStore',
    root: {
        text: 'My app',
		expanded: true,
        children: [{
                text: 'Modules',
                expanded: true,
                children: [
					{ leaf:true, text: 'Employees' }, 
                    { leaf:true, text: 'Customers' },
					{ leaf:true, text: 'Products'  }										
                ]
            },{
                text: 'Market',
                expanded: true,
                children: [
                    { leaf:true, text: 'Sales' },
                    { leaf:true, text: 'Budgets' },
					{ leaf:true, text: 'SEO' },
					{ leaf:true, text: 'Statistics' }					
                ]
            },{
                text: 'Support', iconCls:'help-16', 
                children: [
                    { leaf:true, text: 'Submit a ticket' },
                    { leaf:true, text: 'Forum' },
                    { leaf:true, text: 'Visit our web site' }
                ]
            },
            { leaf:true, text: 'Reports' },
            { leaf:true, text: 'Charts' }
        ]
    }
});


Ext.onReady(function(){
			
var myMenuStore = Ext.create('Myapp.sample.store.mainMenu',{});				
var myPanel = Ext.create('Ext.panel.Panel',{
	title:'My first breadcrumb bar...', 
	width:600,
	height:200,
	dockedItems:[{ //Step 1
		xtype : 'breadcrumb',
		dock: 'top', //Step 2
		store: myMenuStore, 
		showIcons: true, 
		selection: myMenuStore.getRoot().childNodes[2].childNodes[0], 
		listeners:{
			'selectionchange':{
				fn:function(mybreadcrumb, node, eOpts){
					var panel = mybreadcrumb.up('panel'); 
					panel.update( 'This is the zone for:<b>' +  node.data.text + '</b>' );
				},
				delay:200
			}				
		}		
	}],
	renderTo:Ext.getBody()		
});		
	
	
});
