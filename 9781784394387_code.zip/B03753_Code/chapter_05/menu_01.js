
Ext.Loader.setConfig({
    enabled: true
});

Ext.require([
    'Ext.button.*',
	'Ext.window.*'
]);

Ext.onReady(function(){
		
	var myButton = Ext.create('Ext.button.Button',{
		text:'Add payment method...',
		iconCls:'addicon-32',
		iconAlign:'left',
		scale:'large',
		renderTo:'normalbuttons',
		menu:[
			{text:'Master Card' },		
			{text:'Visa' },					
			{text:'PayPal' },		
			{text:'Other...' }					
		]
	});
	
});
