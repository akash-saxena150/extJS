// JavaScript Document
Ext.Loader.setConfig({
    enabled: true
});

Ext.require([
    'Ext.button.*',
	'Ext.toolbar.*',
	'Ext.menu.*',
	'Ext.window.*'	
]);

Ext.onReady(function(){
			
var myPanel = Ext.create('Ext.panel.Panel',{
	title:'My first toolbar...', 
	width:450,
	height:200, 
	dockedItems:[{ //Step 1
		xtype : 'toolbar',				
		dock: 'top', //Step 2
		items:[
			{ text:'New record' },	
			{ text:'Edit record' },				
			{ text:'Remove record' }	
		]
	}],
	renderTo:Ext.getBody()		
});		
	
	
});