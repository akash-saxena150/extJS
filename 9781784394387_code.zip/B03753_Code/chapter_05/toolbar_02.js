// JavaScript Document
Ext.Loader.setConfig({
    enabled: true
});

Ext.require([
    'Ext.button.*',
	'Ext.toolbar.*',
	'Ext.menu.*',
	'Ext.window.*'	
]);

Ext.onReady(function(){
			
var myPanel = Ext.create('Ext.panel.Panel',{
	title:'My first toolbar...', 
	width:600,
	height:200, 
	dockedItems:[{ //Step 1
		xtype : 'toolbar',				
		dock: 'top', //Step 2
		items:[
			{ text:'New', iconCls:'addicon-16' },	
			{ text:'Edit', iconCls:'editicon-16'  },				
			{ text:'Remove', iconCls:'deleteicon-16' },
			{ text:'Export', iconCls:'export-16' },
			{ text:'Print', iconCls:'print-16' },
			{ text:'Help', iconCls:'help-16' }	
		]
	}],
	renderTo:Ext.getBody()		
});		
	
	
});
