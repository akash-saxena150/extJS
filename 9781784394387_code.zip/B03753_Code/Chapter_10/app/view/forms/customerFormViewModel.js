
Ext.define('myApp.view.forms.customerFormViewModel', {
    extend:'Ext.app.ViewModel',
    alias: 'viewmodel.customerform', 
	data:{
		action:'add',
		ownerCmp:null, 		
		rec:null		
	},
	formulas:{
		readOnlyId:function(get){
			return (get('action')!=='add'); //?true:false;
//			if (get('action')!='add'){ //Edit action
//				return true; 
//			} else { 
//				return false;
//			} 						
		},
		ownerNotNull:function(get){
			var cmpx = get('ownerCmp'); 
			return (cmpx!==null && cmpx!==undefined); // ?false:true; 
		},
		refName:function(get){
			var value='';
			if (get('action')!=='add'){ //Edit action
				var id = get('rec.id'), custname =get('rec.name'); 
				if (custname===''){ custname ='(not defined)'; } 
				value = 'Editing : ' +  id + ' - ' + custname + "..." ; 									
			} else { 
				value = 'New customer...';
			} 
			var xtypeOwner = this.getView().ownerCt.getXType(); 
			if (xtypeOwner=="customerwindow"){ 
				this.getView().ownerCt.setTitle(value);
			}
			return value; 
		}
	}
});