// JavaScript Document
Ext.define('myApp.view.modules.customers', { //step 1 
    extend: 'Ext.grid.Panel',
    requires: [		
		'Ext.grid.column.Number',
        'Ext.grid.column.Date',
        'Ext.grid.column.Boolean',
        'Ext.view.Table',
        'Ext.button.Button',
        'Ext.toolbar.Fill',
        'Ext.toolbar.Paging',
		'myApp.view.modules.customersController',		
		'myApp.view.forms.customerWindow'
    ], 
	xtype: 'customersmodule',  //step 2
    alias: 'widget.customersmodule',	
	controller: 'customersmodule', 
    frame: false,
    closable: true,
    iconCls: '',
    title: 'Customers...',
	forceFit:true,
	listeners:{ //step 3
		afterrender:{fn:'myafterrender'}, 
		render:{fn:'myrenderevent'}
	},
	initComponent: function() { //step 4 
		var me=this;
		var myStore= me.createCustomersStore();  
		me.store   = myStore; 		
		me.columns =[{ 
				xtype: 'rownumberer',  
				width: 50, 
				align:'center'
			},{ 
				xtype: 'numbercolumn',
				width: 70, 
				dataIndex: 'id',
				text: 'Id', 
				format: '0'
			},{
				xtype: 'templatecolumn',
				text: 'Country',
				dataIndex: 'country',			
				tpl: '<div> <div class="flag_{[values.country.toLowerCase()]}">&nbsp</div> &nbsp;&nbsp;{country}</div>'
			},{
				xtype: 'gridcolumn',
				width: 210,
				dataIndex: 'name',
				text: 'Customer name'
			},{
				xtype: 'datecolumn',
				dataIndex:'clientSince',
				width: 120,
				text: 'Client Since',
				format: 'M-d-Y',
				align:'center'
			},{
				xtype: 'booleancolumn',
				dataIndex:'sendnews',
				width: 100,	
				align:'center',
				text: 'Send News?',
				falseText: 'No',
				trueText: 'Yes'
			}
		]; 
		me.dockedItems=[{
				xtype: 'toolbar', dock: 'top',
				items: [{
						xtype: 'button', text: 'New...',  iconCls:'addicon-16', action:'newrecord', listeners: {click:'bntactionclick' }    
					},{
						xtype: 'button', text: 'Edit...', iconCls:'editicon-16', action:'editrecord', listeners: {click:'bntactionclick' } 
					},{
						xtype: 'button', text: 'Delete...', iconCls:'deleteicon-16', action:'deleterecord', listeners: {click:'bntactionclick' } 
					},{
						xtype: 'tbfill'
					},{
						xtype: 'button', text: 'Help.', iconCls:'help-16', action:'showhelp' //, listeners: {click:'bntactionclick' } 
					}
				]
			}
//			,{
//				xtype: 'pagingtoolbar', dock: 'bottom',
//				store: myStore , 
//				displayInfo: false, displayMsg: 'Displaying {0} - {1} of {2} customer(s)'				
//			}
		];
		me.callParent();
	},
	createCustomersStore:function(){ 		
		return Ext.create('myApp.store.Customers'); 
	}
});