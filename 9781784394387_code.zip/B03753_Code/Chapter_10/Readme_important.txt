Read chapter 10 of the book, after the part on using Sencha CMD to create the basic application skeleton 
in your application folder paste these folders
