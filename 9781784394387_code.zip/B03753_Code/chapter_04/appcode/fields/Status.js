// JavaScript Document
Ext.define('Myapp.fields.Status',{
    extend: 'Ext.data.field.String',
    alias: 'data.field.status',
    validators: {
        type: 'inclusion',
        list: [ 'Active', 'Inactive'],
		message: 'Is not a valid status value, please select the proper options [Active,Inactive]'
    }
});