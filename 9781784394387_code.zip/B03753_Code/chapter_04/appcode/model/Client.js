// JavaScript Document

Ext.define('Myapp.model.Client',{
	extend:'Ext.data.Model',  // step 1
	idProperty:'clientId ',   // step 2
	fields:[ // step 3
		{name: 'clientId', type: 'int'	},
		{name: 'name'    , type: 'string'},
		{name: 'phone'   , type: 'string'},
		{name: 'website' , type: 'string'},
		{name: 'status'  , type: 'string'},
		{name: 'clientSince' , type: 'date', dateFormat: 'Y-m-d H:i'}
	]	
});