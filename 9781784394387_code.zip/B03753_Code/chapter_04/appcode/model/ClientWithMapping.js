// JavaScript Document

Ext.define('Myapp.model.ClientWithMapping',{
	extend:'Ext.data.Model',  // step 1
	idProperty:'clientId ',   // step 2
	fields:[ // step 3
		{name: 'clientId', type: 'int'	},
		{name: 'name'    , type: 'string'},
		{name: 'phone'   , type: 'string'},
		{name: 'contractFileName', type: 'string', mapping: 'x0001' }
	]	
});