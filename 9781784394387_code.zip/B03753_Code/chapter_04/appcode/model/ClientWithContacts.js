// JavaScript Document
Ext.define('Myapp.model.ClientWithContacts',{
	extend:'Ext.data.Model',  // step 1
	requires: ['Myapp.model.Employee'],
	idProperty:'id ',   // step 2
	fields:[ // step 3
		{name: 'id', type: 'int'},
		{name: 'name'    , type: 'string'},
		{name: 'phone'   , type: 'string'},
		{name: 'website' , type: 'string'},
		{name: 'status'  , type: 'string'},
		{name: 'clientSince' , type: 'date', dateFormat: 'Y-m-d H:i'}
	],
	hasMany:{
		model:'Myapp.model.Employee', name:'employees',  associationKey: 'employees'
	}
});