// JavaScript Document

Ext.define('Myapp.model.ClientWithValidations',{
	extend:'Ext.data.Model',  // step 1
	idProperty:'clientId ',   // step 2
	fields:[ // step 3
		{name: 'clientId', type: 'int'	},
		{name: 'name'    , type: 'string'},
		{name: 'phone'   , type: 'string'},
		{name: 'website' , type: 'string'},
		{name: 'status'  , type: 'string'},
		{name: 'clientSince' , type: 'date', dateFormat: 'Y-m-d H:i'}
	],
	validators:{
		name:[
			{ type:'presence', message:'Name must be present (custom message)' }	 // allowEmpty:false, message:'Name must be present'
		],
		website:[
			{ type:'presence', allowEmpty:true},
			{ type:'length',  min: 5, max:250 }			
		]			
	}	
});