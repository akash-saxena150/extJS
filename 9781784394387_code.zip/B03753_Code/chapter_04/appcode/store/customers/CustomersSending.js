// JavaScript Document
Ext.define('Myapp.store.customers.CustomersSending',{
	extend:'Ext.data.Store',
	model: 'Myapp.model.Customer',   
	autoLoad:false,
	autoSync:true, 
	proxy:{
		type:'ajax',
		url: 'serverside/customers.json',
		api: { 
			read    : 'serverside/customers.json',
			create  : 'serverside/process.php?action=new',			
			update  : 'serverside/process.php?action=update',
			destroy : 'serverside/process.php?action=destroy'
		},
		reader: {
        	type:'json', 
			rootProperty:'records'
        },
		writer:{
			type:'json',  
			encode:true, 
			rootProperty:'paramProcess', 
			allowSingle:false,
			writeAllFields:true,
			root:'records'
		},
		actionMethods:{
			create: 'POST', 
			read: 'GET', 
			update: 'POST', 
			destroy: 'POST'
		}
	}
});
