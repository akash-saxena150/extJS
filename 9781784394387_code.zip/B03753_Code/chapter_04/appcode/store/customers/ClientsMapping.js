// JavaScript Document
Ext.define('Myapp.store.customers.ClientsMapping',{
	extend:'Ext.data.Store',
	model: 'Myapp.model.ClientWithMapping',   
	autoLoad:false,
	proxy:{
		type:'ajax',
		url: 'serverside/mappings.json',
		reader: {
        	type:'json', rootProperty:'records'
        }
	}
});
