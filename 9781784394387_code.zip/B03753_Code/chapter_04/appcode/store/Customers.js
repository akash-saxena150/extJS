// JavaScript Document
Ext.define('Myapp.store.Customers',{
	extend:'Ext.data.Store',    	 //Step 1
	model: 'Myapp.model.Customer'   //Step 2
});
