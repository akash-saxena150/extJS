
Ext.Loader.setConfig({
    enabled: true,
	paths:{
		Myapp:'appcode'	
	}	
});

Ext.require([
	'Ext.data.*', 
	'Myapp.model.Employee',
	'Myapp.model.ClientWithContacts'
]);

Ext.onReady(function(){
	//step 1
	var myclient = Ext.create('Myapp.model.ClientWithContacts',{ 
	  id  		: 10001,
	  name		: 'Acme corp',
	  phone		: '+52-01-55-4444-3210',
	  website   : 'www.acmecorp.com',
	  status    : 'Active',
	  clientSince: '2010-01-01 14:35'
	});	
	//Step 2
	myclient.employees().add(
		{id:101,clientId:10001, name:'Juan Perez', phone:'+52-05-2222-333',email:'juan@test.com',gender:'male'},
		{id:102,clientId:10001, name:'Sonia Sanchez', phone:'+52-05-1111-444',email:'sonia@test.com',gender:'female'}		
	);
	//Step 3
	myclient.employees().each(function(record){
  		console.log(record.get('name') + ' - ' + record.get('email') );
	});
	


});