
Ext.onReady(function(){
	
	Ext.Ajax.request({
		url    : "serverside/myfirstdata.xml",
		success  : function(response,options){
			var xml = response.responseXML;
			var node = xml.getElementsByTagName('msg')[0];
			Ext.Msg.alert("Message", node.firstChild.data );
		},
		failure  : function(response,options){
			Ext.Msg.alert("Message", 'server-side failure with status code ' + response.status);	
		}, 
		callback: function( options, success, response ){ 
			console.log('Callback executed, we can do some stuff !'); 	
		}
	});

});