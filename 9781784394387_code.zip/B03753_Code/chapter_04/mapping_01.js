Ext.Loader.setConfig({
    enabled: true,
	paths:{		
		Myapp:'appcode'	
	}	
});

Ext.require([
	'Ext.data.*', 
	'Myapp.model.ClientWithMapping',
	'Myapp.store.customers.ClientsMapping'
]);

Ext.onReady(function(){
	
	//Step 1
	var store = Ext.create("Myapp.store.customers.ClientsMapping"); 
	//counting the elements in the store
	store.load(function(records, operation, success) {	
		console.log('loaded records');
		Ext.each(records, function(record, index, records){
			console.log('Customer: '  +record.get("name")  + 
			' - '  + record.get("contractFileName") );
		});	
		
	});

});