Ext.Loader.setConfig({
    enabled: true,
	paths:{		
		Myapp:'appcode'	
	}	
});

Ext.require([
	'Ext.data.*', 
	'Myapp.model.Contract',
	'Myapp.model.Customer',
	'Myapp.store.customers.CustomersNested'
]);

Ext.onReady(function(){
	
	//Step 1
	var store = Ext.create("Myapp.store.customers.Customers"); 
	//counting the elements in the store
	store.load(function(records, operation, success) {	
		console.log('loaded records');
		Ext.each(records, function(record, index, records){
			console.log( record.get("name")  + '  - '  + record.data.contractInfo.contractId );
		});	
		
	});

});