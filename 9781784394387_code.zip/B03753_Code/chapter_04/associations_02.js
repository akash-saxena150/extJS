
Ext.Loader.setConfig({
    enabled: true,
	paths:{
		Myapp:'appcode'	
	}	
});

Ext.require([
	'Ext.data.*', 
	'Myapp.model.Contract',
	'Myapp.model.Customer'
]);

Ext.onReady(function(){
	//step 1
	var myclient = Ext.create('Myapp.model.Customer',{ 
	  id  		: 10001,
	  name		: 'Acme corp',
	  phone		: '+52-01-55-4444-3210',
	  website   : 'www.acmecorp.com',
	  status    : 'Active',
	  clientSince: '2010-01-01 14:35', 
	  contractInfo:{id:444, contractId:'ct-001-444', documentType:'PDF' }
	});	
	
	console.log(myclient.data);
	console.log("Second test"); 
	
	var myclientx = Ext.create('Myapp.model.Customer',{ 
	  id  		: 10001,
	  name		: 'Acme corp',
	  phone		: '+52-01-55-4444-3210',
	  website   : 'www.acmecorp.com',
	  status    : 'Active',
	  clientSince: '2010-01-01 14:35'
	});	
	
	console.log(myclientx.data); 


});