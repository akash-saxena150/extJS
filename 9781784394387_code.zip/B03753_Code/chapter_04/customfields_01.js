
Ext.Loader.setConfig({
    enabled: true,
	paths:{
		Myapp:'appcode'	
	}	
});

Ext.require([
    'Ext.data.*',
	'Myapp.fields.Status', 
	'Myapp.model.ClientWithCustomFields'
]);

Ext.onReady(function(){
	//step1
	var myclient = Ext.create('Myapp.model.ClientWithCustomFields',{ 
	  clientId  : '10001',
	  name		: 'Acme corp',
	  phone		: '+52-01-55-4444-3210',
	  website   : 'www.acmecorp.com',
	  status    : 'Active',
	  clientSince: '2010-01-01 14:35'
	});	

	if 	(myclient.isValid()){  //step2
		console.log("myclient model is correct"); 
	} 
	// SET methods 	//step3	
	myclient.set('status','No longer client');	
	if 	(myclient.isValid()){ 
		console.log("myclient model is correct"); 
	} else {  //step4
		console.log("myclient model has errors"); 
		var errors = myclient.validate(); // Step 3
		errors.each(function(error){
			console.log(error.field,error.message);
		});
	}					
		
});