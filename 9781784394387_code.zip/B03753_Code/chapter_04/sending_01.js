Ext.Loader.setConfig({
    enabled: true,
	paths:{		
		Myapp:'appcode'	
	}	
});
Ext.require([
	'Ext.data.*', 
	'Myapp.model.Contract',
	'Myapp.model.Customer',
	'Myapp.store.customers.CustomersSending'
]);
Ext.onReady(function(){
	
	var store = Ext.create("Myapp.store.customers.CustomersSending"); //Step 1
	store.load({ // Step 2 load  Store in order to get all records 
	 	scope: this,
		callback: function(records, operation, success) {	
			console.log('loaded records');
			Ext.each(records, function(record, index, records){
				console.log( record.get("name")  + '  - '  + record.data.contractInfo.contractId );
			});	
			var test=11; 
			console.log('Start adding model / record...!');
			// step 3 Add a record 
			var mynewCustomer = Ext.create('Myapp.model.Customer',{ 
				clientId  : '10003',
				name		: 'American Notebooks Corp',
				phone		: '+52-01-55-3333-2200',
				website   : 'www.notebooksdemo.com',
				status    : 'Active',
				clientSince: '2015-06-01 10:35',
				contractInfo:{
					"id":99990, 
					"contractId":"ct-00301-99990", 
					"documentType":"DOC" 
				}	  
			});	
			store.add(mynewCustomer);	
			
			// step 4 update a record 
			
			console.log('Updating model / record...!');	
			var updateCustomerModel = store.getAt(0);
			updateCustomerModel.beginEdit(); 
			updateCustomerModel.set("website","www.acmecorpusa.com");
			updateCustomerModel.set("phone","+52-01-33-9999-3000");
			updateCustomerModel.endEdit();

			//updateCustomerModel.save(); 
			//store.commitChanges(); 
			//console.log('Sync records...!');
			
			// step 5 delete  a record 
			console.log('deleting a model / record ...!');	
			
			var deleteCustomerModel = store.getAt(1);
			store.remove(deleteCustomerModel);	
			//store.sync();
			
		}
	});

});