
Ext.onReady(function(){
	Ext.Ajax.request({
		url: "serverside/myfirstdata.json",
		success: function( response, options ){
			console.log('success function executed, here we can do some stuff !'); 	
		},
		failure: function( response, options ){
			Ext.Msg.alert("Message", 'server-side failure with status code ' + response.status);	
		}, 
		callback: function( options, success, response ){ 
			if (success){
				var data = Ext.decode(response.responseText);
				Ext.Msg.alert("Message", data.msg);			
			} 
		} 
	});
});