
Ext.Loader.setConfig({
    enabled: true,
	paths:{
		Myapp:'appcode'	
	}	
});

Ext.require([
    'Ext.data.*',
	'Myapp.model.Client'
]);

Ext.onReady(function(){
	
		var myclient = Ext.create('Myapp.model.Client',{
		  clientId: '10001',
		  name: 'Acme corp',
		  phone: '+52-01-55-4444-3210',
		  website: 'www.acmecorp.com',
		  status: 'Active',
		  clientSince: '2010-01-01 14:35'
		});		
		
		console.log(myclient);
		console.log("My client's name is = " + myclient.get('name') );  	//Alternative  = console.log("My client's name is = " + myclient.data.name );
		console.log("My client's website is = " + myclient.get('website')); 	//Alternative  = console.log("My client's website is = " + myclient.data.website ); 		
		console.log("My client's phone is = " +  myclient.get('phone')); 		//Alternative  = console.log("My client's phone is = " + myclient.data.phone); 
		
		// GET Method
		var nameClient = myclient.get('name'); 
		var websiteClient = myclient.get('website'); 
		console.log("My client's info= " + nameClient + " - " + websiteClient); 
		
		// SET methods 		
		myclient.set('phone','+52-01-55-0001-8888'); // single value 
		console.log("My client's new phone is = " + myclient.get('phone')); 
		// Alternative  
		// console.log("My client's new phone is = " + myclient.data.phone); 		
				
		myclient.set({ //Multiple values
			name: 'Acme Corp of AMERICA LTD.',
			website:'www.acmecorp.net'
		})
		console.log("My client's name changed to = " + myclient.data.name); 				
		console.log("My client's website changed to = " + myclient.data.website); 		
	
});