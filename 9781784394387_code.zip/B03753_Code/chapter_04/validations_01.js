
Ext.Loader.setConfig({
    enabled: true,
	paths:{
		Myapp:'appcode'	
	}	
});

Ext.require([
    'Ext.data.*',
	'Myapp.model.ClientWithValidations'
]);

Ext.onReady(function(){
	//step1
	var myclient = Ext.create('Myapp.model.ClientWithValidations',{ 
	  clientId  : '10001',
	  name		: 'Acme corp',
	  phone		: '+52-01-55-4444-3210',
	  website   : 'www.acmecorp.com',
	  status    : 'Active',
	  clientSince: '2010-01-01 14:35'
	});	

	if 	(myclient.isValid()){  //step2
		console.log("myclient model is correct"); 
	} 

	console.log(myclient);
	console.log("My client's name is = " + myclient.get('name') ); 
	console.log("My client's website is = " + myclient.get('website') ); 		
	
	// SET methods 	//step3	
	myclient.set('name','');  
	myclient.set('website',''); 

	if 	(myclient.isValid()){ 
		console.log("myclient model is correct"); 
	} else {  //step4
		console.log("myclient model has errors"); 
		var errors = myclient.validate(); // Step 3
		errors.each(function(error){
			console.log(error.field,error.message);
		});
	}					
		
});