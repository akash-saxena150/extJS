// JavaScript Document
Ext.Loader.setConfig({
    enabled: true,
	paths:{
		Myapp:'appcode'	
	}	
});
Ext.require([
	'Ext.data.*',
	'Ext.view.*',
	'Ext.panel.Panel',	
	//'Ext.view.*',
	'Myapp.model.users',
	'Myapp.store.users'
]);
Ext.onReady(function(){
	Ext.tip.QuickTipManager.init();
	var myStore = Ext.create('Myapp.store.users');
	var myXTemplate = new Ext.XTemplate( //step 1
		'<tplfor=".">', 
		'<div class="user {[this.getActiveclass(values.active)]}">',
			'<div class="user_row">',
				'<div class="user_img">',
					'<img src="images/{twitter_account}.jpg" width="37" height="37">',
				'</div>',
				'<div  class="usr_name">{firstName} {lastName}<br>',
					'<span class="usr_account">{twitter_account}</span>',
				'</div>',
			'</div>',
		'</div>',
		'</tpl>', 
		{
			getActiveclass:function(value){
				return (value!=0)?"active":"inactive"; 
				/*
				if (value!=0){ 
					return "active"; 
				} else {
					return "inactive";
				}
				*/
			}						
		}	
	);
	var myDataview = Ext.create('Ext.view.View', {
		store: myStore, 
		tpl:myXTemplate, 
		padding:6,
		itemSelector: 'div.user',
		emptyText: '<b>No users available</b>',
		listeners:{
			'itemdblclick':{
				fn:function( view, record, item, index, event, eOpts  ){
					if(record.get('active')){ // check if the user is active (step four)
						Ext.fly(item).removeCls('active');
						Ext.fly(item).addCls('inactive');        
					}else{
						Ext.fly(item).removeCls('inactive');
						Ext.fly(item).addCls('active');
					}
					record.data.active = !record.data.active;    
				}						
			}
		}
	});
	var MyPanel = Ext.create('Ext.panel.Panel',{
		title:'My Dataview with advanced XTemplate',
		height:340, width:700,		
		items:[myDataview],
		renderTo:'myPanel'
	}); 
});