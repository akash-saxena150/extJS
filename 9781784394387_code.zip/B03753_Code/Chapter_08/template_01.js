// JavaScript Document
Ext.Loader.setConfig({
    enabled: true,
	paths:{
		Myapp:'appcode'	
	}	
});

Ext.require([
	'Ext.tip.*', 
	'Ext.Template'
]);

Ext.onReady(function(){
	Ext.tip.QuickTipManager.init();	
	var myTemplate = new Ext.Template([
		'<div class="container">',
			'<div class="header">',
				'<img src="images/{logo}"width="88" height="53" alt=""/>',
				'<span>{titlecontents}</span><br>',
			'</div>',
			'<div class="bookscontainer">',
					'<span class="book">',
						'<img src="images/{book_a}" width="112" height="138"  alt="" data-qtitle="Hot book"  data-qtip="This is another great book for EXT JS!" />',
					'</span>',
					'<span class="book">',
						'<img src="images/{book_b}" width="112" height="138"   alt="" data-qtitle="Trend book" data-qtip="This is another great book for EXT JS!" />',
					'</span>',       
			'</div>',
			'<div class="footer">',
				'<a href="{url}" target="_blank">click here to see more</a>',
			'</div>',
		'</div>'
	]);
	myTemplate.compile();
	myTemplate.append('myPanel', {
		logo: 'Packt.png', 
		titlecontents: 'Visit PACK PUB for great deals...!', 		
		book_a: '4005OScov.jpg.png', 
		book_b: '6846OS.jpg.png',
		url: 'https://www.packtpub.com/'
	});	
	
});
