// JavaScript Document
Ext.define('Myapp.model.users',{
	extend:'Ext.data.Model',  // step 1 (extend datamodel)
	idProperty:'id',  
	fields:[ // step 2 (field definition)
		{name: 'id'		 , type: 'int'},
		{name: 'firstName'    , type: 'string'},
		{name: 'lastName'   , type: 'string'},
		{name: 'twitter_account' , type: 'string'},
		{name: 'active'  , type: 'boolean'},
		{name: 'avatar'  , type: 'string'}
	]
});