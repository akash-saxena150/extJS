// JavaScript Document
Ext.define('Myapp.store.users',{
	extend:'Ext.data.Store',
	model: 'Myapp.model.users',   
	autoLoad:true, 
	proxy:{
		type:'ajax',
		url: 'serverside/users.json',
		reader: {
        	type:'json', 
			totalProperty:'total',
			rootProperty:'records'
        }
	}
});
