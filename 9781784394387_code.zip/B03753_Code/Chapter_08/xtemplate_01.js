// JavaScript Document
Ext.Loader.setConfig({
    enabled: true,
	paths:{
		Myapp:'appcode'	
	}	
});
Ext.require([
	'Ext.data.*',
	'Ext.view.*',
	'Ext.panel.Panel',	
	//'Ext.view.*',
	'Myapp.model.users',
	'Myapp.store.users'
]);
Ext.onReady(function(){
	Ext.tip.QuickTipManager.init();
	var myStore = Ext.create('Myapp.store.users');
	var myXTemplate = new Ext.XTemplate( //Step 1
		'<tplfor=".">', //Step 2
			'<div class="user">',
				'Record number {[xindex]} - {firstName} {lastName}  - ', //Step 3 
				'<tpl if="active ==0">', //Step 4
					'<span class="inactiveuser">user is Inactive (need activation)</span>',
				'<tpl else>',
					'<span class="activeuser">user is active</span>',
				'</tpl>',
				'- Reference number for user :', 
				'{id+1000}',  //Step 5
			'</div>',
		'</tpl>'		
	); 
	myStore.on({ //Step 6
		'load':{
			fn:function(store, records, success, eOpts){
				var data=[];	 //Step 7			
				Ext.each(records, function(record, index, records){
					data.push(record.data); 
				},this);	
				var myEl = Ext.get('myPanel');
				myXTemplate.overwrite(myEl, data);  //Step 8
			},
			scope:this				
		}			
	});
	myStore.load(); 
});