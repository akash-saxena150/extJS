// JavaScript Document
Ext.Loader.setConfig({
    enabled: true,
	paths:{
		Myapp:'appcode'	
	}	
});
Ext.require([
	'Ext.data.*',
	'Ext.view.*',
	'Ext.panel.Panel',	
	//'Ext.view.*',
	'Myapp.model.users',
	'Myapp.store.users'
]);
Ext.onReady(function(){
	Ext.tip.QuickTipManager.init();
	var myStore = Ext.create('Myapp.store.users');
	var myTpl =	[
	'<tplfor=".">',
	'<div class="user">{firstName} {lastName}</div>',
	'</tpl>'		
	].join('');
	var myDataview = Ext.create('Ext.view.View', {
		store: myStore, 
		tpl:myTpl, 
		padding:6,
		itemSelector: 'div.user',
		emptyText: '<b>No users available</b>',
		listeners:{
			itemclick:{
				fn:function( view, record, item, index, evt, eOpts  ){
				 	Ext.Msg.alert(
						"Dataview record selected",
						record.get('firstName') + " " + record.get('lastName') + " has been selected"
					);
				}						
			}
		}
	});
	var MyPanel = Ext.create('Ext.panel.Panel',{
		title:'My Dataview',
		height:295, width:450,		
		items:[myDataview],
		renderTo:'myPanel'
	}); 
});