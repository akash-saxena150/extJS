/*
 * File: app/view/AvailableFields01.js
 */
Ext.define('Myapp.view.TriggerFields01', {
    extend: 'Ext.form.Panel',
    alias: 'widget.TriggerFields01',
    requires: ['Ext.form.*'],
    height: 200, width:500,
    bodyPadding: 6,
    header: true,
    title: 'Triggers',
	defaultType:'textfield',
	defaults:{
		anchor:'-18',
		labelWidth:150, 
		labelAlign:'right'	
	},
	initComponent: function() {
		var me = this;
		var myItems = me.createFields();
		Ext.applyIf(me,{
			items: myItems
		});
		me.callParent(arguments);									
	}, 
	createFields: function (){
		var newItems=[];						
		
		var myTriggers = Ext.create('Ext.form.field.Text', {
			fieldLabel: 'My Field with triggers',
			triggers: {
				searchtext: {
					cls: 'x-form-search-trigger',
					handler: function() {
						Ext.Msg.alert('Alert', 'Trigger search was clicked');
						this.setValue('searching text...');	
					}
				},
				cleartext: {
					cls: 'x-form-clear-trigger',
					handler: function() {						
						Ext.Msg.alert('Alert', 'Trigger clear was clicked');
						this.setValue('');						
					}
				}
			}
		});
		newItems.push( myTriggers );

		return newItems; 		
	} 
});