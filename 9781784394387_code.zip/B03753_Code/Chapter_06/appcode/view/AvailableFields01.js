/*
 * File: app/view/AvailableFields01.js
 */
Ext.define('Myapp.view.AvailableFields01', {
    extend: 'Ext.form.Panel',
    alias: 'widget.availablefields01',
    requires: ['Ext.form.*'],
    height: 530, width:500,
    bodyPadding: 6,
    header: true,
    title: 'Available Fields',
	defaultType:'textfield',
	defaults:{
		anchor:'-18',
		labelWidth:135, 
		labelAlign:'right'	
	},
	initComponent: function() {
		var me = this;
		var myItems = me.createFields();
		Ext.applyIf(me,{
			items: myItems
		});
		me.callParent(arguments);									
	}, 
	createFields: function (){
		var newItems=[];						
		// Step 1 		
		var myTextField = Ext.create('Ext.form.field.Text',{
			 fieldLabel:'Name',
			 name:'firstname',
			 enableKeyEvents : true,
			 minLength : 4,
			 minLengthText: 'Name is too short, we need at least {0} chars..!',
			 maxLength : 25,
			 minLengthText: 'Name is too long, maximum length is {0} chars..!'			 
		});
		// Step 2 (asign listener to the text field)
		myTextField.on({
			keyup:{
				fn:function( thisField, evt, eOpts ){
				  if(evt.getCharCode() === evt.ENTER){
						if (thisField.getValue()!=''){ 
							Ext.Msg.alert('Alert','Welcome: '+ thisField.getValue() );
						}
				  }
				}				
			}
		});	
		newItems.push( myTextField );		
		var myAgeField = Ext.create('Ext.form.field.Number',{
			fieldLabel:'Age', name:'age', 
			minValue: 18,
			maxValue: 70,
			allowDecimals : false,
			hideTrigger:true		
		});	
	
		var myIncomeField = Ext.create('Ext.form.field.Number',{
			fieldLabel:'Income', name:'income', 			
			minValue: 0,
			allowDecimals : true,  
			decimalPrecision : 2,
			negativeText : 'The income cannot be negative..!',
			msgTarget:'side', 
			step: 500
		});
		newItems.push( myAgeField );
		newItems.push( myIncomeField );
		
		//Combo Step 1  (store) 
//		var occupationStore = Ext.create('Ext.data.Store',{
//		  fields  : ['id','name'],
//		  data	: [
//			{id:1 ,name:'CEO'},
//			{id:2 ,name:'Vicepresident'},
//			{id:3 ,name:'Marketing manager'},
//			{id:4 ,name:'Development manager'},
//			{id:5 ,name:'Sales manager'}
//		  ]
//		});

		var occupationStore = Ext.create('Ext.data.Store',{
		  fields  : ['id','name'],
		  autoLoad:true, 
		  proxy:{
			type:'ajax' , 
			url :'serverside/occupations.json', 
			reader:{
				type:'json',
				root:'records'	
			}			  
		  }
		});
		
		//Combo Step 2  (create field) 		
		var myFirstCombo  = Ext.create('Ext.form.field.ComboBox', {
			fieldLabel: 'Occupation',
			store: occupationStore,
			queryMode: 'local',
			displayField: 'name',
			valueField: 'id'
		});	
		
		myFirstCombo.on('select',function(combo,records){
		  	Ext.Msg.alert('Alert',records[0].get('name'));
		});
		newItems.push( myFirstCombo );
		
		var zonesStore = Ext.create('Ext.data.Store',{
		  fields  : ['id','name'],
		  data	: [
			{id:1 ,name:'Zone A'},
			{id:2 ,name:'Zone B'},
			{id:3 ,name:'Zone C'},
			{id:4 ,name:'Zone D'},
			{id:5 ,name:'Zone E'}
		  ]
		});	
		var myFirstTag  =Ext.create('Ext.form.field.Tag', {
			fieldLabel: 'Select zone',
		 	store: zonesStore, 
			displayField: 'name',
			valueField: 'id',
			filterPickList: true,
			queryMode: 'local'
		});
		newItems.push( myFirstTag );
		
		var datefield = Ext.create('Ext.form.field.Date',{
		  fieldLabel: 'Birthday',
		  name: 'birthday',
		  format:'d-M-Y', 
		  submitFormat:'Y-m-d'
		});
		newItems.push( datefield );
	
		var mysinglecheckbox = Ext.create('Ext.form.field.Checkbox',{
			fieldLabel:' ',
			labelSeparator:'',
			boxLabel  : 'employee has hobbies ? ',
			name    : 'hobbies'
		});
		newItems.push( mysinglecheckbox );
	
	
		var groupCheckboxes = Ext.create('Ext.form.CheckboxGroup',{
		  fieldLabel  : 'Hobbies',
		  columns    : 2,
		  items    : [
			{name:'hobby',boxLabel:'Videogames',inputValue:'vg'},
			{name:'hobby',boxLabel:'Sports',inputValue:'sp'},
			{name:'hobby',boxLabel:'Card games',inputValue:'cg'},
			{name:'hobby',boxLabel:'Movies',inputValue:'mv'},
			{name:'hobby',boxLabel:'Collecting toys',inputValue:'ct'},
			{name:'hobby',boxLabel:'Music',inputValue:'ms'},
			{name:'hobby',boxLabel:'Others...',inputValue:'ot'}
		  ]
		});
		newItems.push( groupCheckboxes );
	
		var radioYes = Ext.create('Ext.form.field.Radio',{
		  name  : 'option',		  
		  fieldLabel  : 'Employee has a car?',
		  labelSeparator : '',
		  boxLabel: 'Yes',
		  inputValue  : true
		}); 				
		var radioNo = Ext.create('Ext.form.field.Radio',{
		  name    : 'option',
		  hideLabel:true,   // instead of use :   fieldLabel  : ' ', labelSeparator : '',
		  boxLabel: 'No',
		  inputValue  : false
		});
		newItems.push( radioYes, radioNo  );
	
		var radioGroup  = {
	        xtype: 'radiogroup',
	        fieldLabel: 'Employee level',
	        columns: 2,
    	    vertical:true,
			items: [
				{ boxLabel: 'Begginer', name: 'rb', inputValue: '1' },
				{ boxLabel: 'Intermediate', name: 'rb', inputValue: '2'},
				{ boxLabel: 'Advanced', name: 'rb', inputValue: '3', checked: true },
				{ boxLabel: 'Ninja', name: 'rb', inputValue: '4' }
			]
		};
		newItems.push( radioGroup );

		var myFieldContainer = {
			xtype: 'fieldcontainer',
			height: '',
			fieldLabel: 'Shoes / Dress size',
			layout: { type: 'hbox'},
			items: [{
					xtype: 'numberfield',
					flex: 1,
					fieldLabel: ''
				},{
					xtype: 'splitter'
				},{
					xtype: 'combobox',
					flex: 1,
					hideLabel:true,   // instead of use :   fieldLabel  : ' ', labelSeparator : '',
					labelWidth: 10, 
					store:Ext.create('Ext.data.Store',{
					  fields  : ['id','name'],
					  data	: [
						{id:1 ,name:'small'},
						{id:2 ,name:'medium'},
						{id:3 ,name:'large'},
						{id:4 ,name:'Xl'},
						{id:5 ,name:'XXL'}
					  ]
					}),
					queryMode: 'local',
					displayField: 'name',
					valueField: 'id'						
				}
			]
		};
		newItems.push( myFieldContainer );
		
		return newItems; 		
	} 
});