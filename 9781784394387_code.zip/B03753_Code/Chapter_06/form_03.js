// JavaScript Document
Ext.Loader.setConfig({
    enabled: true,
	paths:{
		Myapp:'appcode'	
	}	
});
Ext.require([
	'Ext.form.*',
	'Ext.toolbar.*',
	'Ext.button.*',
	'Myapp.view.TriggerFields01'
]);
Ext.onReady(function(){
	var mypanel = Ext.create('Myapp.view.TriggerFields01',{
		renderTo: Ext.getBody()		
	});
});