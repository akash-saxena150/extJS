<?php 
	$result = array(
		'success'=>true, 
		'datasend'=> $_POST	
	);	
	echo json_encode($result);
?>